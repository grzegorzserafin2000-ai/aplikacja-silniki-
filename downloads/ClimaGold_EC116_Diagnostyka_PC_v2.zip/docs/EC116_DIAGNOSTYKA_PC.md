# EC116 — bezpośrednia diagnostyka z komputera

Ten program jest przeznaczony do połączenia:

**komputer Windows 10/11 → jeden adapter USB–RS485 → jeden silnik**.

Centrala ani sterownik Carel nie są potrzebne. Program sam wysyła ustalone
zapytania MODBUS FC03/FC04 i zapisuje odpowiedzi. Nie jest wcześniejszym
rejestratorem pasywnym i nie wymaga drugiego odbiornika. Python nie jest
potrzebny do uruchomienia EXE.

## Uruchomienie

1. Otwórz `EC116_DIAGNOSTYKA_PC_v2.exe` dwukrotnym kliknięciem.
2. Wybierz port adaptera i aktualne połączenie silnika. Domyślnie jest to
   Nawiew 1: adres 231, 9600, 8N2. Możesz wybrać Wywiew 1, fabryczne lub
   własne połączenie. To wybór parametrów odczytu, nie zmiana ustawień silnika.
3. Przeczytaj i potwierdź warunki stanowiska. Następnie kliknij
   **ODCZYTAJ SILNIK I ZAPISZ RAPORT**.
4. Wynik pojawi się w oknie. Przycisk **Otwórz folder raportu** otwiera katalog
   z `RAPORT.txt`, `diagnostyka.json` i `trace.jsonl`.

Folder powstaje automatycznie w Dokumentach, w katalogu `ClimaGold`.
Wybór fabrycznych sprawdza wyłącznie 247 / 19200 / 8E1. Nie przywraca
komunikacji ani innych parametrów. Nie ma skanowania całej magistrali,
automatycznego ponawiania ani samoczynnego otwierania portu po uruchomieniu.

## Warunki pierwszego zapytania

Stanowisko musi być zabezpieczone, wirnik nieruchomy, a niezależny wyłącznik
zasilania sprawny i dostępny.
Komputer jest jedynym masterem; inne programy MODBUS muszą być zamknięte.
Program służy do diagnostyki przed próbami ruchu. Nie należy go używać do
automatycznego odzyskiwania połączenia po utracie sterowania pracującym silnikiem.

**Odczyt MODBUS może odnowić watchdog i wznowić wcześniejsze dodatnie zadanie.**
Dlatego sam brak zapisów parametrów nie dowodzi, że pierwszy odczyt będzie
obojętny dla napędu po wcześniejszej pracy. Sprawdzenie h17 wymaga już
pierwszego zapytania. Warunki fizyczne muszą być zapewnione przed nim.
Przycisk przerwania kończy odczyt, nie wysyła STOP. Zamknięcie programu,
wyjęcie USB i niezależny ręczny wyłącznik nie są dowodem automatycznego
zatrzymania przez watchdog.

## Co mierzymy

Pierwsze odczyty dotyczą h17 i h2. Wartość niezerowa kończy sesję bez
kontynuowania odpytywania. Następnie program sprawdza i1=0x0101, i0=2100,
odczytuje sygnaturę i parametry zestawu, h1/h3/h4/h5/h7/h8/h16/h25/h30,
statusy i aktualne RPM. Na końcu ponownie sprawdza identyfikację, h2 i h17.
Kontrola końcowa porównuje także wszystkie sześć słów sygnatury i3–i8 oraz
i2/i9 z początkiem. Niezerowy odczyt RPM przerywa dalsze zapytania;
program nie przypisuje automatycznie przyczyny ruchu ani nie wysyła STOP.

Raport rozróżnia brak odczytu i 0 RPM. Pojedynczy odczyt 0 RPM nie jest próbą
skuteczności STOP. Wartość h8 to zapisane ustawienie maksimum, nie automatycznie
prędkość znamionowa z tabliczki. P/N i typ silnika pozostają deklaracją z
tabliczki; samo i1 nie potwierdza całego wariantu sprzętowego.

Sesja zapisuje dokładne żądania i odpowiedzi z czasami, sprawdza CRC,
adres, funkcję, długość i wyjątki MODBUS. Brak odpowiedzi, błędna ramka,
zmieniona identyfikacja lub przerwanie kończą odczyt bez retransmisji.
Istniejące pliki raportu nie są nadpisywane. Zapis z błędem jest oznaczony
jako niepełny; brak miejsca na dysku może pozostawić urwany plik.

## Co pozostaje przed uruchomieniem wirnika

Program nie zawiera poleceń START, STOP, PIN, resetu ani zmian parametrów.
Nie odblokowuje testu Android. Dokładne komendy i reakcja FW21 nadal wymagają
potwierdzenia dla tego wariantu, a potem kontrolowanej próby STOP, zaniku
całej komunikacji, powrotu i odtworzenia ustawień. Program diagnostyczny
sam takiej próby nie wykonuje i nie zatwierdza.

Dokument E076 w dostarczonej wersji kończy zakres zgodności na FW14.
Nazwy `SpeedReq_ZA` i `FrcOff_ZA` w Carelu nie są mapą adresów RTU FW21.
Dlatego dodatnie zadanie ani eksperymentalne zmiany h5/h17 nie zostały
udostępnione przez sam fakt dostępności wyłącznika.

Odczyt h17=0 oznacza brak ustawionego watchdoga według dostępnej mapy;
h5=1570 nie jest zerową prędkością zastępczą. Sam ręczny wyłącznik nie
zapewnia automatycznego zatrzymania po utracie komunikacji.

Sprawdzenia automatyczne i otwarcie okna w Linux/Mono nie zastępują
uruchomienia na Windowsie ani rzeczywistej próby na silniku.
