using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.Ports;
using System.Text;
using System.Threading;

namespace ClimaGold.Ec116
{
    // The diagnostic master has one fixed read plan. There is no write-register API.
    public interface IActivePort : IDisposable
    {
        void Open();
        int Read(byte[] buffer, int offset, int count);
        void Write(byte[] buffer, int offset, int count);
        void Close();
    }

    public interface IActiveClock
    {
        void Restart();
        long Milliseconds { get; }
    }

    public sealed class ActiveClock : IActiveClock
    {
        private readonly Stopwatch watch = new Stopwatch();
        public void Restart() { watch.Restart(); }
        public long Milliseconds { get { return watch.ElapsedMilliseconds; } }
    }

    public sealed class ActiveSettings
    {
        public string PortName;
        public int Slave;
        public int Baud;
        public string Frame;
        public int ReplyTimeoutMs = 500;
        public string LogPath;
        public string JsonReportPath;
        public string TextReportPath;

        public void Validate()
        {
            if (String.IsNullOrWhiteSpace(PortName)) throw new ArgumentException("Wybierz port COM.");
            if (Slave < 1 || Slave > 247) throw new ArgumentException("Adres MODBUS musi należeć do zakresu 1–247; bez rozgłoszeń.");
            if (Array.IndexOf(new int[] { 4800, 9600, 14400, 19200, 38400, 57600, 115200 }, Baud) < 0)
                throw new ArgumentException("Nieobsługiwana prędkość transmisji.");
            if (Array.IndexOf(new string[] { "8N1", "8N2", "8E1", "8E2", "8O1", "8O2" }, Frame) < 0)
                throw new ArgumentException("Nieobsługiwany format transmisji.");
            if (ReplyTimeoutMs < 100 || ReplyTimeoutMs > 2000) throw new ArgumentException("Limit odpowiedzi: 100–2000 ms.");
            string[] paths = new string[] { LogPath, JsonReportPath, TextReportPath };
            HashSet<string> distinct = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string path in paths)
            {
                if (String.IsNullOrWhiteSpace(path)) throw new ArgumentException("Podaj trzy ścieżki plików wynikowych.");
                string full = Path.GetFullPath(path);
                if (!distinct.Add(full)) throw new ArgumentException("Pliki wynikowe muszą mieć różne nazwy.");
                if (!Directory.Exists(Path.GetDirectoryName(full))) throw new DirectoryNotFoundException("Brak katalogu wynikowego: " + Path.GetDirectoryName(full));
                if (File.Exists(full) || Directory.Exists(full)) throw new IOException("Plik wynikowy już istnieje: " + full);
            }
        }

        internal ActiveSettings Copy()
        {
            return new ActiveSettings { PortName = PortName, Slave = Slave, Baud = Baud, Frame = Frame,
                ReplyTimeoutMs = ReplyTimeoutMs, LogPath = LogPath, JsonReportPath = JsonReportPath, TextReportPath = TextReportPath };
        }
    }

    public sealed class ActiveResult
    {
        public string Status = "error";
        public string Error = "";
        public bool CompleteDiagnostics;
        public bool PhysicalTrialVerified;
        public bool StartAuthorized;
        public bool DoNotReconnect;
        public bool IdentityRechecked;
        public int? Rpm;
        public int ReadCount;
        public long ElapsedMs;
        public string LogPath;
        public string JsonReportPath;
        public string TextReportPath;
        public readonly Dictionary<string, int> Snapshot = new Dictionary<string, int>();
    }

    public sealed class SerialActivePort : IActivePort
    {
        private readonly SerialPort port;
        private bool attemptedOpen;
        public SerialActivePort(ActiveSettings settings)
        {
            if (settings == null) throw new ArgumentNullException("settings");
            // Validate serial settings without requiring report files to exist or be opened here.
            ActiveSettings safe = settings.Copy();
            if (String.IsNullOrWhiteSpace(safe.PortName) || safe.Slave < 1 || safe.Slave > 247 ||
                Array.IndexOf(new int[] { 4800, 9600, 14400, 19200, 38400, 57600, 115200 }, safe.Baud) < 0 ||
                Array.IndexOf(new string[] { "8N1", "8N2", "8E1", "8E2", "8O1", "8O2" }, safe.Frame) < 0)
                throw new ArgumentException("Nieprawidłowe ustawienia portu.");
            Parity parity = safe.Frame[1] == 'E' ? Parity.Even : safe.Frame[1] == 'O' ? Parity.Odd : Parity.None;
            port = new SerialPort(safe.PortName, safe.Baud, parity, 8, safe.Frame[2] == '2' ? StopBits.Two : StopBits.One);
            // These settings are applied BEFORE Open; no flow-control line drives DE.
            port.Handshake = Handshake.None;
            port.DtrEnable = false;
            port.RtsEnable = false;
            port.ReadTimeout = 20;
            port.WriteTimeout = 100;
        }
        public void Open()
        {
            if (attemptedOpen) throw new InvalidOperationException("Ten transport jest jednorazowy; bez automatycznego ponownego połączenia.");
            attemptedOpen = true;
            port.Open();
        }
        public int Read(byte[] buffer, int offset, int count) { return port.Read(buffer, offset, count); }
        public void Write(byte[] buffer, int offset, int count)
        {
            // Even direct calls cannot transmit configuration writes, broadcasts or raw data.
            if (!ActiveDiagnostics.AllowedRequest(buffer, offset, count))
                throw new InvalidOperationException("Dozwolony jest wyłącznie pojedynczy odczyt FC03/FC04 z planu diagnostyki.");
            port.Write(buffer, offset, count);
        }
        public void Close() { if (port.IsOpen) port.Close(); }
        public void Dispose() { port.Dispose(); }
    }

    public static class ActiveDiagnostics
    {
        private sealed class Request
        {
            internal readonly byte Function;
            internal readonly int Register;
            internal readonly bool Final;
            internal Request(byte function, int register, bool final = false) { Function = function; Register = register; Final = final; }
            internal string Name { get { return (Function == 3 ? "h" : "i") + Register; } }
        }

        private static readonly Request[] Plan = new Request[] {
            new Request(3,17), new Request(3,2), new Request(4,1), new Request(4,0),
            new Request(4,2), new Request(4,3), new Request(4,4), new Request(4,5),
            new Request(4,6), new Request(4,7), new Request(4,8), new Request(4,9),
            new Request(4,10), new Request(4,12), new Request(4,13), new Request(4,14),
            new Request(3,1), new Request(3,3), new Request(3,4), new Request(3,5),
            new Request(3,7), new Request(3,8), new Request(3,16), new Request(3,25), new Request(3,30),
            new Request(4,1,true), new Request(4,0,true),
            new Request(4,2,true), new Request(4,3,true), new Request(4,4,true), new Request(4,5,true),
            new Request(4,6,true), new Request(4,7,true), new Request(4,8,true), new Request(4,9,true),
            new Request(3,2,true), new Request(3,17,true)
        };
        private static readonly object OwnershipLock = new object();
        private static readonly HashSet<IActivePort> OwnedPorts = new HashSet<IActivePort>();

        internal static ushort Crc(byte[] bytes, int offset, int count)
        {
            ushort crc = 0xffff;
            for (int i = offset; i < offset + count; i++)
            {
                crc ^= bytes[i];
                for (int bit = 0; bit < 8; bit++) crc = (ushort)((crc & 1) != 0 ? (crc >> 1) ^ 0xa001 : crc >> 1);
            }
            return crc;
        }

        internal static bool AllowedRequest(byte[] bytes, int offset, int count)
        {
            if (bytes == null || offset < 0 || count != 8 || offset > bytes.Length - count) return false;
            if (bytes[offset] < 1 || bytes[offset] > 247 || bytes[offset + 4] != 0 || bytes[offset + 5] != 1) return false;
            byte function = bytes[offset + 1];
            int register = (bytes[offset + 2] << 8) | bytes[offset + 3];
            bool permitted = false;
            foreach (Request request in Plan) if (request.Function == function && request.Register == register) { permitted = true; break; }
            ushort crc = Crc(bytes, offset, 6);
            return permitted && bytes[offset + 6] == (byte)crc && bytes[offset + 7] == (byte)(crc >> 8);
        }

        private static byte[] Encode(int slave, Request request)
        {
            byte[] bytes = new byte[] { (byte)slave, request.Function, (byte)(request.Register >> 8), (byte)request.Register, 0, 1, 0, 0 };
            ushort crc = Crc(bytes, 0, 6);
            bytes[6] = (byte)crc; bytes[7] = (byte)(crc >> 8);
            if (!AllowedRequest(bytes, 0, bytes.Length)) throw new InvalidOperationException("Plan zawiera niedozwolony odczyt.");
            return bytes;
        }

        private static string Quote(string value)
        {
            StringBuilder text = new StringBuilder("\"");
            foreach (char c in value ?? "")
            {
                switch (c)
                {
                    case '"': text.Append("\\\""); break;
                    case '\\': text.Append("\\\\"); break;
                    case '\n': text.Append("\\n"); break;
                    case '\r': text.Append("\\r"); break;
                    case '\t': text.Append("\\t"); break;
                    default: if (c < 32) text.Append("\\u" + ((int)c).ToString("x4")); else text.Append(c); break;
                }
            }
            return text.Append('"').ToString();
        }

        private static string Hex(byte[] bytes) { return BitConverter.ToString(bytes).Replace('-', ' ').ToLowerInvariant(); }
        private static string Bool(bool value) { return value ? "true" : "false"; }
        private static void Emit(StreamWriter writer, IActiveClock clock, string kind, string fields)
        {
            if (writer == null) return;
            writer.WriteLine("{\"t_ms\":" + clock.Milliseconds + ",\"event\":" + Quote(kind) + fields + "}");
            writer.Flush();
        }

        private static StreamWriter Reserve(string path)
        {
            return new StreamWriter(new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.Read), new UTF8Encoding(false));
        }

        private static int ReadWord(ActiveSettings settings, IActivePort port, Request request, CancellationToken cancel, IActiveClock clock, StreamWriter log)
        {
            cancel.ThrowIfCancellationRequested();
            byte[] tx = Encode(settings.Slave, request);
            List<byte> response = new List<byte>();
            bool replyLogged = false;
            long deadline = clock.Milliseconds + settings.ReplyTimeoutMs;
            try
            {
                Emit(log, clock, "tx", ",\"direction\":\"tx\",\"register\":" + Quote(request.Name) + ",\"final_check\":" + Bool(request.Final) + ",\"hex\":" + Quote(Hex(tx)));
                cancel.ThrowIfCancellationRequested();
                if (clock.Milliseconds >= deadline) throw new TimeoutException("Upłynął limit przed nadaniem żądania.");
                port.Write(tx, 0, tx.Length);
                byte[] chunk = new byte[256];
                while (true)
                {
                    cancel.ThrowIfCancellationRequested();
                    if (clock.Milliseconds >= deadline) throw new TimeoutException("Brak pełnej odpowiedzi w stałym limicie " + settings.ReplyTimeoutMs + " ms.");
                    int count;
                    try { count = port.Read(chunk, 0, chunk.Length); }
                    catch (TimeoutException) { continue; }
                    if (count < 0 || count > chunk.Length) throw new IOException("Transport zwrócił nieprawidłową liczbę bajtów.");
                    if (count > 0)
                    {
                        byte[] captured = new byte[count];
                        Buffer.BlockCopy(chunk, 0, captured, 0, count);
                        response.AddRange(captured);
                        Emit(log, clock, "rx_chunk", ",\"direction\":\"rx\",\"validation\":\"pending\",\"register\":" + Quote(request.Name) + ",\"hex\":" + Quote(Hex(captured)));
                    }
                    cancel.ThrowIfCancellationRequested();
                    // Bytes arriving at or after the original deadline never extend or satisfy it.
                    if (clock.Milliseconds >= deadline) throw new TimeoutException("Odpowiedź przekroczyła stały limit " + settings.ReplyTimeoutMs + " ms.");
                    if (response.Count < 2) continue;
                    int expected = (response[1] & 0x80) != 0 ? 5 : 7;
                    if (response.Count < expected) continue;
                    byte[] raw = response.ToArray();
                    if (raw.Length != expected) throw new IOException("Nadmiarowe bajty odpowiedzi; oczekiwano dokładnie " + expected + ".");
                    if (raw[0] != settings.Slave) throw new IOException("Inny adres urządzenia w odpowiedzi.");
                    if (raw[1] != request.Function && raw[1] != (request.Function | 0x80)) throw new IOException("Inna funkcja w odpowiedzi.");
                    ushort crc = Crc(raw, 0, raw.Length - 2);
                    if (raw[raw.Length - 2] != (byte)crc || raw[raw.Length - 1] != (byte)(crc >> 8)) throw new IOException("Nieprawidłowy CRC odpowiedzi.");
                    if ((raw[1] & 0x80) != 0) throw new IOException("Wyjątek MODBUS: " + raw[2] + ".");
                    if (raw[2] != 2) throw new IOException("Nieprawidłowa liczba bajtów danych; wymagane 2.");
                    int value = (raw[3] << 8) | raw[4];
                    // Require the RTU frame boundary before another request. In particular,
                    // never accept a valid seven-byte prefix with a trailing noise byte.
                    int bitsPerCharacter = 1 + 8 + (settings.Frame[1] == 'N' ? 0 : 1) + (settings.Frame[2] == '2' ? 2 : 1);
                    int quietMs = Math.Max(2, (int)Math.Ceiling(3.5 * bitsPerCharacter * 1000.0 / settings.Baud));
                    long lastByteAt = clock.Milliseconds;
                    while (clock.Milliseconds - lastByteAt < quietMs)
                    {
                        cancel.ThrowIfCancellationRequested();
                        if (clock.Milliseconds >= deadline) throw new TimeoutException("Nie potwierdzono końca ramki przed stałym limitem odpowiedzi.");
                        int extra;
                        try { extra = port.Read(chunk, 0, chunk.Length); }
                        catch (TimeoutException) { continue; }
                        if (extra < 0 || extra > chunk.Length) throw new IOException("Transport zwrócił nieprawidłową liczbę bajtów.");
                        if (extra > 0)
                        {
                            byte[] captured = new byte[extra];
                            Buffer.BlockCopy(chunk, 0, captured, 0, extra);
                            response.AddRange(captured);
                            Emit(log, clock, "rx_chunk", ",\"direction\":\"rx\",\"validation\":\"pending\",\"register\":" + Quote(request.Name) + ",\"hex\":" + Quote(Hex(captured)));
                            throw new IOException("Nadmiarowe bajty po odpowiedzi; brak poprawnej granicy ramki RTU.");
                        }
                    }
                    cancel.ThrowIfCancellationRequested();
                    if (clock.Milliseconds >= deadline) throw new TimeoutException("Koniec ramki przekroczył stały limit odpowiedzi.");
                    Emit(log, clock, "rx", ",\"direction\":\"rx\",\"valid\":true,\"register\":" + Quote(request.Name) + ",\"hex\":" + Quote(Hex(raw)) + ",\"value\":" + value);
                    replyLogged = true;
                    return value;
                }
            }
            catch (Exception error)
            {
                if (!replyLogged) Emit(log, clock, "rx", ",\"direction\":\"rx\",\"valid\":false,\"register\":" + Quote(request.Name) + ",\"hex\":" + Quote(Hex(response.ToArray())) + ",\"reason\":" + Quote(error.Message));
                throw;
            }
        }

        private static void RequireInitialQuiet(IActivePort port, CancellationToken cancel, IActiveClock clock, StreamWriter log)
        {
            // Do not drain a stale reply and then proceed: any pre-request traffic
            // invalidates this fresh, single-master diagnostic session.
            long until = clock.Milliseconds + 50;
            byte[] buffer = new byte[256];
            while (clock.Milliseconds < until)
            {
                cancel.ThrowIfCancellationRequested();
                int count;
                try { count = port.Read(buffer, 0, buffer.Length); }
                catch (TimeoutException) { continue; }
                if (count < 0 || count > buffer.Length) throw new IOException("Transport zwrócił nieprawidłową liczbę bajtów przed pierwszym żądaniem.");
                if (count > 0)
                {
                    byte[] raw = new byte[count]; Buffer.BlockCopy(buffer, 0, raw, 0, count);
                    Emit(log, clock, "unsolicited_rx", ",\"direction\":\"rx\",\"valid\":false,\"hex\":" + Quote(Hex(raw)) + ",\"reason\":\"traffic_before_first_request\"");
                    throw new IOException("Odebrano dane przed pierwszym żądaniem. Możliwa stara odpowiedź lub inny master; nie nadano żadnego odczytu. Nie czyść bufora ani nie ponawiaj połączenia.");
                }
            }
            cancel.ThrowIfCancellationRequested();
            Emit(log, clock, "initial_quiet", ",\"required_ms\":50,\"confirmed\":true");
        }

        private static void CheckValue(Request request, int value)
        {
            if (request.Function == 3 && request.Register == 17 && value != 0)
                throw new IOException("h17=" + value + ": watchdog jest aktywny lub jego tryb jest nieznany. Sam odczyt mógł odnowić watchdog. Nie łącz ponownie; użyj niezależnego odcięcia zasilania.");
            if (request.Function == 3 && request.Register == 2 && value != 0)
                throw new IOException("h2=" + value + ": zapisane żądanie jest niezerowe. Nie łącz ponownie; użyj niezależnego odcięcia zasilania.");
            if (request.Function == 4 && request.Register == 1 && value != 0x0101)
                throw new IOException("Nie potwierdzono tożsamości EC116: i1=" + value + (request.Final ? " podczas kontroli końcowej." : "."));
            if (request.Function == 4 && request.Register == 0 && value != 2100)
                throw new IOException("Nie potwierdzono firmware 21.00: i0=" + value + (request.Final ? " podczas kontroli końcowej." : "."));
        }

        private static void SetError(ActiveResult result, Exception error)
        {
            result.Status = error is OperationCanceledException ? "cancelled" : "error";
            result.CompleteDiagnostics = false;
            result.DoNotReconnect = true;
            result.Error += (result.Error.Length == 0 ? "" : "; ") + error.GetType().Name + ": " + error.Message;
        }

        public static ActiveResult Run(ActiveSettings settings, IActivePort port, CancellationToken cancellation,
            Action<string> progress = null, IActiveClock suppliedClock = null)
        {
            ActiveResult result = new ActiveResult();
            IActiveClock clock = suppliedClock ?? new ActiveClock();
            StreamWriter log = null, json = null, text = null;
            bool ownsPort = false;
            Dictionary<string, int> initialSignature = new Dictionary<string, int>();
            clock.Restart();
            try
            {
                if (port == null) throw new ArgumentNullException("port");
                lock (OwnershipLock)
                {
                    if (!OwnedPorts.Add(port)) throw new InvalidOperationException("Transport ma już oczekujące żądanie diagnostyczne.");
                    ownsPort = true;
                }
                if (settings == null) throw new ArgumentNullException("settings");
                settings = settings.Copy();
                result.LogPath = settings.LogPath; result.JsonReportPath = settings.JsonReportPath; result.TextReportPath = settings.TextReportPath;
                settings.Validate();
                // All three evidence files are reserved with CreateNew BEFORE the COM port opens.
                log = Reserve(settings.LogPath); json = Reserve(settings.JsonReportPath); text = Reserve(settings.TextReportPath);
                Emit(log, clock, "metadata", ",\"mode\":\"single_adapter_modbus_diagnostic_master\",\"port\":" + Quote(settings.PortName) +
                    ",\"slave\":" + settings.Slave + ",\"baud\":" + settings.Baud + ",\"frame\":" + Quote(settings.Frame) +
                    ",\"reply_timeout_ms\":" + settings.ReplyTimeoutMs + ",\"utc\":" + Quote(DateTime.UtcNow.ToString("o", CultureInfo.InvariantCulture)) +
                    ",\"physical_trial_verified\":false,\"start_authorized\":false,\"automatic_retry\":false,\"continuous_polling\":false");
                cancellation.ThrowIfCancellationRequested();
                port.Open();
                RequireInitialQuiet(port, cancellation, clock, log);
                foreach (Request request in Plan)
                {
                    cancellation.ThrowIfCancellationRequested();
                    int value = ReadWord(settings, port, request, cancellation, clock, log);
                    result.Snapshot[request.Name] = value;
                    result.ReadCount++;
                    CheckValue(request, value);
                    if (request.Function == 4 && request.Register >= 2 && request.Register <= 9)
                    {
                        if (!request.Final) initialSignature.Add(request.Name, value);
                        else if (initialSignature[request.Name] != value)
                            throw new IOException("Zmieniona sygnatura urządzenia " + request.Name + ": początkowo " + initialSignature[request.Name] + ", końcowo " + value + ". Nie potwierdzono tej samej jednostki.");
                        if (!request.Final && request.Register == 9)
                        {
                            bool allZero = true;
                            for (int uid = 3; uid <= 8; uid++) if (initialSignature["i" + uid] != 0) allZero = false;
                            if (allZero) throw new IOException("UID i3..i8 jest całkowicie zerowy; nie można potwierdzić sygnatury konkretnej jednostki.");
                        }
                    }
                    if (request.Function == 4 && request.Register == 14)
                    {
                        result.Rpm = value;
                        if (value > 0) throw new IOException("i14=" + value + " obr./min: zaobserwowano niezerowy odczyt RPM na stanowisku wymagającym postoju. Dalsze odczyty przerwano. Odczyt nie ustala przyczyny ani usterki; w razie zagrożenia użyj niezależnego odcięcia zasilania.");
                    }
                    if (progress != null) progress(request.Name + " = " + value);
                }
                cancellation.ThrowIfCancellationRequested();
                result.IdentityRechecked = true;
                result.Status = "completed";
                result.CompleteDiagnostics = true;
            }
            catch (Exception error)
            {
                SetError(result, error);
                try { Emit(log, clock, "failure", ",\"status\":" + Quote(result.Status) + ",\"error\":" + Quote(result.Error) + ",\"do_not_reconnect\":true"); }
                catch (Exception logError) { SetError(result, logError); }
            }
            finally
            {
                if (ownsPort)
                {
                    try { port.Close(); } catch (Exception error) { SetError(result, error); }
                    try { port.Dispose(); } catch (Exception error) { SetError(result, error); }
                    lock (OwnershipLock) { OwnedPorts.Remove(port); }
                }
                result.ElapsedMs = clock.Milliseconds;
                try { Emit(log, clock, "finish", ",\"status\":" + Quote(result.Status) + ",\"complete_diagnostics\":" + Bool(result.CompleteDiagnostics) + ",\"physical_trial_verified\":false,\"start_authorized\":false,\"read_count\":" + result.ReadCount + ",\"error\":" + Quote(result.Error)); }
                catch (Exception error) { SetError(result, error); }
                // A valid zero is distinct from an absent/untrusted RPM response.
                try { if (json != null) { json.WriteLine(JsonReport(settings, result)); json.Flush(); } }
                catch (Exception error) { SetError(result, error); }
                try { if (text != null) { text.Write(HumanReport(settings, result)); text.Flush(); } }
                catch (Exception error) { SetError(result, error); }
                foreach (StreamWriter writer in new StreamWriter[] { text, json, log })
                    if (writer != null) { try { writer.Dispose(); } catch (Exception error) { SetError(result, error); } }
            }
            return result;
        }

        private static string JsonReport(ActiveSettings settings, ActiveResult result)
        {
            StringBuilder snapshot = new StringBuilder("{");
            List<string> names = new List<string>(result.Snapshot.Keys); names.Sort(StringComparer.Ordinal);
            foreach (string name in names)
            {
                if (snapshot.Length > 1) snapshot.Append(',');
                snapshot.Append(Quote(name)).Append(':').Append(result.Snapshot[name]);
            }
            snapshot.Append('}');
            return "{\"schema\":\"ec116-pn192648-fw21-diagnostic-v1\",\"status\":" + Quote(result.Status) +
                ",\"complete_diagnostics\":" + Bool(result.CompleteDiagnostics) + ",\"physical_trial_verified\":false,\"start_authorized\":false" +
                ",\"identity_rechecked\":" + Bool(result.IdentityRechecked) + ",\"unit_signature_rechecked\":" + Bool(result.IdentityRechecked) + ",\"do_not_reconnect\":" + Bool(result.DoNotReconnect) +
                ",\"error\":" + Quote(result.Error) + ",\"read_count\":" + result.ReadCount + ",\"elapsed_ms\":" + result.ElapsedMs +
                ",\"slave\":" + (settings == null ? "null" : settings.Slave.ToString(CultureInfo.InvariantCulture)) +
                ",\"rpm_snapshot\":" + (result.Rpm.HasValue ? result.Rpm.Value.ToString(CultureInfo.InvariantCulture) : "null") +
                ",\"rpm_snapshot_trusted\":" + Bool(result.CompleteDiagnostics && result.IdentityRechecked && result.Rpm.HasValue) +
                ",\"rpm_is_continuous\":false,\"h8_meaning\":\"saved_setting_not_verified_rated_maximum\",\"snapshot\":" + snapshot +
                ",\"log_path\":" + Quote(result.LogPath) + ",\"limitations\":\"Read requests may refresh an already active watchdog; h2 and h17 are checked first and last. Initial quiet rejects queued traffic, but arbitrarily delayed stale RTU replies cannot be perfectly correlated. No motion, STOP, watchdog or power-loss behavior was physically verified.\"}";
        }

        public static string HumanReport(ActiveSettings settings, ActiveResult result)
        {
            StringBuilder report = new StringBuilder("Cel: EC116 / PN192648 / firmware 21.00 — świeża diagnostyka przed próbą ruchu\n");
            report.Append("Wynik: ").Append(result.Status).Append("; komplet odczytów: ").Append(result.CompleteDiagnostics ? "TAK" : "NIE").Append('\n');
            report.Append("Próba fizyczna zweryfikowana: NIE. START dozwolony: NIE.\n");
            if (settings != null) report.Append("Port: ").Append(settings.PortName).Append("; adres: ").Append(settings.Slave).Append("; ").Append(settings.Baud).Append(" ").Append(settings.Frame).Append('\n');
            report.Append("RPM — pojedynczy zapis chwilowy: ").Append(result.Rpm.HasValue ? result.Rpm.Value + " obr./min" : "NIEZNANE (brak poprawnego odczytu)").Append(". Bez ciągłego odpytywania.\n");
            report.Append("Odczyty poprawne protokołowo: ").Append(result.ReadCount).Append(" / ").Append(Plan.Length).Append(". Kontrola końcowa tożsamości i warunków: ").Append(result.IdentityRechecked ? "potwierdzona" : "niepotwierdzona").Append(".\n");
            report.Append("Sygnatura konkretnej jednostki i2..i9 (w tym sześć słów UID i3..i8) jest porównywana na początku i na końcu odczytu; sama zgodność i1/i0 potwierdza jedynie rodzinę i firmware.\n");
            if (!result.CompleteDiagnostics) report.Append("Sesja jest niepełna lub błędna: zapisanych wartości, w tym RPM, nie należy traktować jako potwierdzonego kompletnego obrazu urządzenia.\n");
            if (result.Error.Length > 0) report.Append("Błąd / przerwanie: ").Append(result.Error).Append('\n');
            if (result.DoNotReconnect) report.Append("NIE ŁĄCZ PONOWNIE w tej sesji. Przy zagrożeniu użyj niezależnego odcięcia zasilania. Nie wysłano automatycznej ponownej próby.\n");
            report.Append("h8 jest zapisaną nastawą, a nie potwierdzonym znamionowym maksimum silnika.\n");
            report.Append("Wartości poniżej są surowymi odczytami, a nie potwierdzeniem mapy sterowania, obsługi ruchu, skuteczności STOP ani zachowania po utracie łączności.\n");
            List<string> names = new List<string>(result.Snapshot.Keys); names.Sort(StringComparer.Ordinal);
            foreach (string name in names) report.Append(name).Append(" = ").Append(result.Snapshot[name]).Append(" / 0x").Append(result.Snapshot[name].ToString("X4")).Append('\n');
            report.Append("Wysłano wyłącznie pojedyncze odczyty FC03/FC04. Nie wysłano START, STOP ani zapisu parametrów.\n");
            report.Append("Nawet pierwszy odczyt h17 może odnowić wcześniej aktywny watchdog; przy niezerowym h17 lub h2 diagnostyka natychmiast kończy komunikację. Odczyty nie mają gwarancji obojętności przy zachowanym żądaniu lub aktywnym watchdogu.\n");
            report.Append("Przed pierwszym żądaniem wymagane jest 50 ms ciszy magistrali; odebrane wcześniej dane przerywają sesję. RTU nie pozwala jednak całkowicie wykluczyć dowolnie opóźnionej starej odpowiedzi.\n");
            report.Append("Do tej czynności wymagane są zabezpieczone, odizolowane stanowisko, jeden master i operator przy niezależnym odcięciu zasilania. Pojedynczy odczyt 0 RPM nie dowodzi bezpiecznego postoju ani skutecznego STOP.\n");
            return report.ToString();
        }
    }
}
