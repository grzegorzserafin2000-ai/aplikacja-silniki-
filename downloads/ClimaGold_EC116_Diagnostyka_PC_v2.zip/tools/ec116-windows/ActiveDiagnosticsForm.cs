using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Ports;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace ClimaGold.Ec116
{
    // This entry point is separate from the older passive recorder.
    // Only the fixed read-only diagnostic engine is reachable from this window.
    public sealed class ActiveDiagnosticsForm : Form
    {
        private readonly Color orange = Color.FromArgb(255, 137, 26);
        private readonly ComboBox ports = new ComboBox();
        private readonly ComboBox preset = new ComboBox();
        private readonly ComboBox baud = new ComboBox();
        private readonly ComboBox frame = new ComboBox();
        private readonly NumericUpDown address = new NumericUpDown();
        private readonly CheckBox secured = new CheckBox();
        private readonly CheckBox initialSession = new CheckBox();
        private readonly Button read = new Button();
        private readonly Button cancel = new Button();
        private readonly Button openReport = new Button();
        private readonly Label status = new Label();
        private readonly TextBox results = new TextBox();
        private readonly BackgroundWorker worker = new BackgroundWorker();
        private readonly List<Control> idleControls = new List<Control>();
        private CancellationTokenSource cancellation;
        private string reportDirectory;
        private bool closing;
        private bool latched;

        public ActiveDiagnosticsForm()
        {
            Text = "Clima Gold — EC116 / komputer ↔ silnik";
            BackColor = Color.FromArgb(20, 20, 20);
            ForeColor = Color.WhiteSmoke;
            Font = new Font("Segoe UI", 10F);
            AutoScaleMode = AutoScaleMode.Dpi;
            ClientSize = new Size(930, 700);
            MinimumSize = new Size(880, 650);
            StartPosition = FormStartPosition.CenterScreen;
            TableLayoutPanel page = new TableLayoutPanel {
                Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 10,
                Padding = new Padding(22), AutoScroll = true
            };
            page.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            foreach (int height in new int[] { 45, 54, 47, 49, 94, 49, 64, 47, 44 })
                page.RowStyles.Add(new RowStyle(SizeType.Absolute, height));
            page.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            Controls.Add(page);
            page.Controls.Add(LabelOf("CLIMA GOLD   /   DIAGNOSTYKA EC116", 19, orange), 0, 0);
            page.Controls.Add(LabelOf("Komputer + jeden adapter USB–RS485 + silnik. Centrala Carel nie jest potrzebna.\nGR20V-4IP.Z8.AR · P/N 192648 · firmware 21.00 — profil do weryfikacji.", 10, ForeColor), 0, 1);

            FlowLayoutPanel connection = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false };
            connection.Controls.Add(SmallLabel("Port USB:", 78));
            ConfigureCombo(ports, 140);
            connection.Controls.Add(ports);
            Button refresh = MakeButton("Odśwież porty", delegate { RefreshPorts(); });
            connection.Controls.Add(refresh);
            connection.Controls.Add(SmallLabel("Połączenie:", 93));
            ConfigureCombo(preset, 325);
            preset.Items.AddRange(new object[] {
                "Nawiew 1 — 231 / 9600 / 8N2",
                "Wywiew 1 — 232 / 9600 / 8N2",
                "Fabryczne — 247 / 19200 / 8E1",
                "Własne połączenie…"
            });
            preset.SelectedIndexChanged += delegate { ApplyPreset(); };
            connection.Controls.Add(preset);
            page.Controls.Add(connection, 0, 2);

            FlowLayoutPanel settings = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false };
            settings.Controls.Add(SmallLabel("Adres:", 58));
            address.Minimum = 1; address.Maximum = 247; address.Value = 231; address.Width = 85;
            StyleInput(address); settings.Controls.Add(address);
            settings.Controls.Add(SmallLabel("Transmisja:", 92));
            ConfigureCombo(baud, 114);
            baud.Items.AddRange(new object[] { "4800", "9600", "14400", "19200", "38400", "57600", "115200" });
            baud.SelectedItem = "9600"; settings.Controls.Add(baud);
            ConfigureCombo(frame, 100);
            frame.Items.AddRange(new object[] { "8N1", "8N2", "8E1", "8E2", "8O1", "8O2" });
            frame.SelectedItem = "8N2"; settings.Controls.Add(frame);
            settings.Controls.Add(SmallLabel("Wybór sprawdza połączenie; nie zmienia ustawień silnika.", 400));
            page.Controls.Add(settings, 0, 3);

            Label warning = LabelOf("PRZED PRÓBĄ RUCHU\nProgram wysyła odczyty MODBUS. Odczyt może odnowić watchdog i wznowić stare zadanie.\nNie używaj go do odzyskiwania łączności po pracy silnika. Zamknięcie programu ani odłączenie USB nie jest poleceniem STOP.", 10, Color.Salmon);
            warning.Padding = new Padding(8);
            warning.BackColor = Color.FromArgb(49, 27, 24);
            page.Controls.Add(warning, 0, 4);

            secured.Text = "Stanowisko jest zabezpieczone, wirnik stoi; mam sprawny wyłącznik zasilania niezależny od komputera.";
            secured.Dock = DockStyle.Fill;
            page.Controls.Add(secured, 0, 5);
            initialSession.Text = "To diagnostyka przed próbą ruchu na bezpiecznie przygotowanym stanowisku.\nPozostałe programy MODBUS są zamknięte. Nie wznawiam połączenia po utracie sterowania podczas pracy.";
            initialSession.Dock = DockStyle.Fill;
            page.Controls.Add(initialSession, 0, 6);

            FlowLayoutPanel actions = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false };
            ApplyButton(read, "ODCZYTAJ SILNIK I ZAPISZ RAPORT", BeginRead);
            read.BackColor = Color.FromArgb(108, 57, 15);
            read.Width = 335;
            ApplyButton(cancel, "Przerwij odczyt (bez STOP silnika)", delegate { CancelRead(); });
            cancel.Enabled = false; cancel.Width = 330;
            actions.Controls.AddRange(new Control[] { read, cancel });
            page.Controls.Add(actions, 0, 7);
            status.Text = "Gotowy. Żaden port nie jest otwarty. START pozostaje zablokowany.";
            status.ForeColor = orange; status.Dock = DockStyle.Fill;
            page.Controls.Add(status, 0, 8);

            TableLayoutPanel output = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2 };
            output.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
            output.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            FlowLayoutPanel links = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false };
            ApplyButton(openReport, "Otwórz folder raportu", delegate { OpenReport(); });
            openReport.Enabled = false;
            links.Controls.Add(openReport);
            links.Controls.Add(MakeButton("Co sprawdza program?", delegate { ShowHelp(); }));
            output.Controls.Add(links, 0, 0);
            results.Multiline = true; results.ReadOnly = true; results.ScrollBars = ScrollBars.Vertical;
            results.Dock = DockStyle.Fill; StyleInput(results);
            results.Text = "Wybierz port i właściwe połączenie. Następnie potwierdź warunki stanowiska i kliknij ODCZYTAJ.\r\n\r\nProgram sprawdzi identyfikację, parametry i aktualne RPM. Zapisze raport oraz ramki żądań i odpowiedzi.\r\nNie wysyła START, STOP, PIN ani zmian konfiguracji. Ten odczyt nie potwierdza jeszcze bezpieczeństwa próby ruchowej.";
            output.Controls.Add(results, 0, 1);
            page.Controls.Add(output, 0, 9);

            idleControls.AddRange(new Control[] { ports, preset, refresh, address, baud, frame, secured, initialSession, read });
            worker.DoWork += ReadWork;
            worker.RunWorkerCompleted += ReadFinished;
            FormClosing += delegate(object sender, FormClosingEventArgs args) {
                if (!worker.IsBusy) return;
                args.Cancel = true; closing = true; CancelRead();
            };
            preset.SelectedIndex = 0;
            RefreshPorts();
        }

        private Label LabelOf(string text, float size, Color color)
        {
            return new Label { Text = text, Font = new Font("Segoe UI", size), ForeColor = color,
                Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft };
        }
        private Label SmallLabel(string text, int width)
        {
            return new Label { Text = text, Width = width, Height = 38, TextAlign = ContentAlignment.MiddleLeft };
        }
        private void StyleInput(Control input) { input.BackColor = Color.FromArgb(41, 41, 41); input.ForeColor = ForeColor; }
        private void ConfigureCombo(ComboBox combo, int width) { combo.Width = width; combo.DropDownStyle = ComboBoxStyle.DropDownList; StyleInput(combo); }
        private Button MakeButton(string text, EventHandler handler) { Button button = new Button(); ApplyButton(button, text, handler); return button; }
        private void ApplyButton(Button button, string text, EventHandler handler)
        {
            button.Text = text; button.AutoSize = true; button.MinimumSize = new Size(110, 38);
            button.FlatStyle = FlatStyle.Flat; button.FlatAppearance.BorderColor = orange;
            button.BackColor = Color.FromArgb(42, 42, 42); button.ForeColor = ForeColor;
            button.Padding = new Padding(8, 0, 8, 0); button.Click += handler;
        }
        private void ApplyPreset()
        {
            int selected = preset.SelectedIndex;
            if (selected >= 0 && selected < 3)
            {
                address.Value = selected == 0 ? 231 : selected == 1 ? 232 : 247;
                baud.SelectedItem = selected == 2 ? "19200" : "9600";
                frame.SelectedItem = selected == 2 ? "8E1" : "8N2";
            }
            bool editable = selected == 3 && !worker.IsBusy;
            address.Enabled = editable; baud.Enabled = editable; frame.Enabled = editable;
        }
        private void RefreshPorts()
        {
            string previous = ports.SelectedItem as string;
            ports.Items.Clear();
            try
            {
                string[] names = SerialPort.GetPortNames(); Array.Sort(names, StringComparer.OrdinalIgnoreCase);
                ports.Items.AddRange(names);
                if (previous != null && ports.Items.Contains(previous)) ports.SelectedItem = previous;
                else if (ports.Items.Count == 1) ports.SelectedIndex = 0;
            }
            catch (Exception error) { status.Text = "Nie udało się wyświetlić portów: " + error.Message; }
        }
        private void SetBusy(bool busy)
        {
            foreach (Control control in idleControls) control.Enabled = !busy;
            cancel.Enabled = busy;
            read.Enabled = !busy && !latched;
            if (!busy) ApplyPreset();
        }
        private void Tell(string message) { MessageBox.Show(this, message, Text, MessageBoxButtons.OK, MessageBoxIcon.Information); }
        private void BeginRead(object sender, EventArgs args)
        {
            if (worker.IsBusy || latched) return;
            if (ports.SelectedItem == null) { Tell("Podłącz adapter USB–RS485 i wybierz Odśwież porty. Jeśli port się nie pojawi, sprawdź jego sterownik w Menedżerze urządzeń Windows."); return; }
            if (!secured.Checked || !initialSession.Checked) { Tell("Przed pierwszym zapytaniem potwierdź oba warunki stanowiska. Odczyt nie służy do odzyskiwania sterowania po próbie ruchowej."); return; }
            try
            {
                string parent = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                if (String.IsNullOrEmpty(parent)) parent = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                reportDirectory = Path.Combine(parent, "ClimaGold", "Diagnostyka_EC116_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + "_" + Guid.NewGuid().ToString("N").Substring(0, 8));
                Directory.CreateDirectory(reportDirectory);
                ActiveSettings settings = new ActiveSettings {
                    PortName = (string)ports.SelectedItem, Slave = (int)address.Value,
                    Baud = Int32.Parse((string)baud.SelectedItem), Frame = (string)frame.SelectedItem,
                    ReplyTimeoutMs = 700,
                    LogPath = Path.Combine(reportDirectory, "trace.jsonl"),
                    JsonReportPath = Path.Combine(reportDirectory, "diagnostyka.json"),
                    TextReportPath = Path.Combine(reportDirectory, "RAPORT.txt")
                };
                settings.Validate();
                cancellation = new CancellationTokenSource();
                SetBusy(true); openReport.Enabled = true;
                status.Text = "Odczytuję h17, następnie h2 i identyfikację. Bez zapisów parametrów.";
                results.Text = "Raport: " + reportDirectory;
                worker.RunWorkerAsync(settings);
            }
            catch (Exception error)
            {
                if (cancellation != null) { cancellation.Dispose(); cancellation = null; }
                SetBusy(false);
                Tell("Nie udało się przygotować odczytu: " + error.Message);
            }
        }
        private void ReadWork(object sender, DoWorkEventArgs args)
        {
            ActiveSettings settings = (ActiveSettings)args.Argument;
            args.Result = ActiveDiagnostics.Run(settings, new SerialActivePort(settings), cancellation.Token, delegate(string message) {
                if (!IsHandleCreated || IsDisposed) return;
                try { BeginInvoke((MethodInvoker)delegate { status.Text = message; }); } catch (InvalidOperationException) { }
            });
        }
        private void ReadFinished(object sender, RunWorkerCompletedEventArgs args)
        {
            cancellation.Dispose(); cancellation = null;
            latched = args.Error != null;
            if (args.Error != null)
            {
                status.Text = "Odczyt przerwany błędem. Bez automatycznego ponawiania.";
                results.Text = "Błąd: " + args.Error.Message + "\r\nRaport może być niepełny: " + reportDirectory;
            }
            else
            {
                ActiveResult result = (ActiveResult)args.Result;
                latched = result.Status != "completed" || result.DoNotReconnect;
                status.Text = result.CompleteDiagnostics ? "Odczyt zakończony. Raport zapisany. START pozostaje zablokowany." : "Odczyt przerwany. Sprawdź raport; nie ponawiam połączenia.";
                string report;
                try { report = File.ReadAllText(result.TextReportPath, Encoding.UTF8); }
                catch { report = "Wynik: " + result.Status + "\r\n" + result.Error + "\r\nNie udało się otworzyć raportu. RPM: stan nieznany. START zablokowany."; }
                string actualOutcome = result.Status != "completed" || !result.CompleteDiagnostics
                    ? "SESJA NIEZAKOŃCZONA POPRAWNIE.\r\n" + result.Error + "\r\nPlik poniżej może być niepełny lub opisywać stan sprzed błędu zapisu.\r\n\r\n" : "";
                results.Text = actualOutcome + report.Replace("\r\n", "\n").Replace("\n", "\r\n") + "\r\n\r\nFolder: " + reportDirectory;
            }
            secured.Checked = false; initialSession.Checked = false;
            SetBusy(false);
            if (closing) Close();
        }
        private void CancelRead()
        {
            if (cancellation == null) return;
            cancellation.Cancel(); cancel.Enabled = false;
            status.Text = "Przerywam odczyt. Nie wysyłam STOP silnika.";
        }
        private void OpenReport()
        {
            if (reportDirectory == null) return;
            try { Process.Start(new ProcessStartInfo(reportDirectory) { UseShellExecute = true }); }
            catch (Exception error) { Tell("Folder raportu: " + reportDirectory + "\n" + error.Message); }
        }
        private void ShowHelp()
        {
            Tell("To bezpośrednia diagnostyka jednego silnika przez jeden adapter USB–RS485. Carel nie jest potrzebny.\n\nWybór Nawiew / Wywiew / Fabryczne określa tylko sprawdzane połączenie. Niczego nie przywraca ani nie programuje.\n\nProgram wysyła wyłącznie ustalone odczyty FC03/FC04. Nie ma START, STOP, PIN, resetu ani zapisu parametrów. Po błędzie, niezerowym zadaniu lub aktywnym watchdogu przerywa sesję.\n\nRaport zawiera odpowiedzi i aktualne RPM; brak odczytu nie jest zerem. Odczyt maksimum h8 to ustawienie, a nie potwierdzona prędkość znamionowa.\n\nOdczyty nie potwierdzają skuteczności STOP ani automatycznego zatrzymania po utracie USB. Ta próba ruchowa pozostaje do wykonania po potwierdzeniu mapy sterowania firmware 21.00.");
        }
    }

    internal static class ActiveProgram
    {
        private static string Argument(string[] args, string name)
        {
            int index = Array.IndexOf(args, name);
            return index >= 0 && index + 1 < args.Length ? args[index + 1] : null;
        }
        [STAThread]
        private static int Main(string[] args)
        {
            bool testing = Array.IndexOf(args, "--self-test") >= 0 || Array.IndexOf(args, "--smoke-test") >= 0;
            try
            {
                if (Array.IndexOf(args, "--self-test") >= 0) return ActiveDiagnosticsTests.Run(Argument(args, "--self-test-report"));
                Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
                using (ActiveDiagnosticsForm form = new ActiveDiagnosticsForm())
                {
                    if (Array.IndexOf(args, "--smoke-test") >= 0)
                    {
                        form.Show(); Application.DoEvents();
                        string snapshot = Argument(args, "--smoke-image");
                        if (snapshot != null)
                            using (Bitmap bitmap = new Bitmap(form.Width, form.Height)) { form.DrawToBitmap(bitmap, form.ClientRectangle); bitmap.Save(snapshot); }
                        string report = Argument(args, "--smoke-report");
                        if (report != null) File.WriteAllText(report, "{\"gui_started\":true,\"port_opened\":false,\"mode\":\"active_read_diagnostics\",\"start_authorized\":false}\n", new UTF8Encoding(false));
                        form.Close();
                    }
                    else Application.Run(form);
                }
                return 0;
            }
            catch (Exception error)
            {
                if (testing) Console.Error.WriteLine(error);
                else MessageBox.Show("Nie udało się uruchomić diagnostyki.\n" + error.Message, "Clima Gold EC116", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 1;
            }
        }
    }
}
