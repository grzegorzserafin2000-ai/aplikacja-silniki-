using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;

namespace ClimaGold.Ec116
{
    // Headless tests: compile this file with ActiveDiagnostics.cs and select this Main.
    public static class ActiveDiagnosticsTests
    {
        private static int passed;
        private static int failed;
        private static readonly List<string> outcomes = new List<string>();

        private sealed class FakeClock : IActiveClock
        {
            public long Now;
            public void Restart() { Now = 0; }
            public long Milliseconds { get { return Now; } }
        }

        private sealed class FakePort : IActivePort
        {
            private readonly FakeClock clock;
            private readonly Queue<byte> pending = new Queue<byte>();
            public readonly List<byte[]> Requests = new List<byte[]>();
            public Func<byte[], int, byte[]> Reply;
            public Action BeforeOpen;
            public Action<int> BeforeRead;
            public Action<int> BeforeQuietRead;
            public int ChunkSize = 7;
            public int ReadStepMs = 1;
            public int Opens;
            public int Closes;
            public int Disposals;
            public int Reads;
            public int ReplyReads;
            public long FirstWriteAtMs = -1;
            public bool Opened;
            public bool Closed;
            public bool ThrowOnOpen;

            public FakePort(FakeClock clock)
            {
                this.clock = clock;
                Reply = delegate(byte[] request, int index) { return GoodReply(request, DefaultValue(request)); };
            }

            public void Open()
            {
                Opens++;
                if (BeforeOpen != null) BeforeOpen();
                if (ThrowOnOpen) throw new IOException("simulated open failure");
                Check(!Opened && !Closed, "port opened more than once");
                Opened = true;
            }

            public void Write(byte[] buffer, int offset, int count)
            {
                Check(Opened && !Closed, "write outside open lifetime");
                Check(pending.Count == 0, "more than one request outstanding");
                byte[] request = new byte[count];
                Array.Copy(buffer, offset, request, 0, count);
                Check(count == 8, "request must contain exactly eight bytes");
                Check(request[0] >= 1 && request[0] <= 247, "broadcast or invalid slave");
                Check(request[1] == 3 || request[1] == 4, "a write opcode was transmitted");
                Check(request[4] == 0 && request[5] == 1, "request must read one register");
                Check(Crc(request, 6) == (request[6] | request[7] << 8), "request CRC");
                if (Requests.Count == 0) FirstWriteAtMs = clock.Now;
                Requests.Add(request);
                byte[] reply = Reply(request, Requests.Count);
                if (reply != null)
                    foreach (byte item in reply) pending.Enqueue(item);
            }

            public int Read(byte[] buffer, int offset, int count)
            {
                Check(Opened && !Closed, "read outside open lifetime");
                Reads++;
                clock.Now += ReadStepMs;
                if (Requests.Count > 0)
                {
                    ReplyReads++;
                    if (BeforeRead != null) BeforeRead(ReplyReads);
                }
                else if (BeforeQuietRead != null) BeforeQuietRead(Reads);
                if (pending.Count == 0) throw new TimeoutException("simulated timeout");
                int length = Math.Min(Math.Min(count, ChunkSize), pending.Count);
                for (int i = 0; i < length; i++) buffer[offset + i] = pending.Dequeue();
                return length;
            }

            public void Close() { Closes++; Closed = true; }
            public void Dispose() { Disposals++; }
            public void Preload(byte[] bytes) { foreach (byte item in bytes) pending.Enqueue(item); }
        }

        private sealed class Session : IDisposable
        {
            public readonly string DirectoryPath;
            public readonly FakeClock Clock;
            public readonly FakePort Port;
            public readonly ActiveSettings Settings;

            public Session()
            {
                DirectoryPath = Path.Combine(Path.GetTempPath(), "ec116-active-test-" + Guid.NewGuid().ToString("N"));
                Directory.CreateDirectory(DirectoryPath);
                Clock = new FakeClock();
                Port = new FakePort(Clock);
                Settings = new ActiveSettings {
                    PortName = "FAKE", Slave = 1, Baud = 19200, Frame = "8E1", ReplyTimeoutMs = 500,
                    LogPath = Path.Combine(DirectoryPath, "capture.jsonl"),
                    JsonReportPath = Path.Combine(DirectoryPath, "report.json"),
                    TextReportPath = Path.Combine(DirectoryPath, "report.txt")
                };
            }

            public ActiveResult Run(CancellationToken cancellation)
            {
                return ActiveDiagnostics.Run(Settings, Port, cancellation, null, Clock);
            }

            public ActiveResult Run() { return Run(CancellationToken.None); }
            public void Dispose() { Directory.Delete(DirectoryPath, true); }
        }

        private static void Check(bool condition, string message)
        {
            if (!condition) throw new Exception(message);
        }

        private static int Register(byte[] request) { return request[2] << 8 | request[3]; }

        private static int DefaultValue(byte[] request)
        {
            int register = Register(request);
            if (request[1] == 3 && (register == 17 || register == 2)) return 0;
            if (request[1] == 4 && register == 1) return 0x0101;
            if (request[1] == 4 && register == 0) return 2100;
            if (request[1] == 4 && register == 14) return 0;
            if (request[1] == 3 && register == 8) return 900;
            return register;
        }

        private static int Crc(byte[] buffer, int count)
        {
            int crc = 0xffff;
            for (int i = 0; i < count; i++)
            {
                crc ^= buffer[i];
                for (int bit = 0; bit < 8; bit++) crc = (crc & 1) != 0 ? (crc >> 1) ^ 0xa001 : crc >> 1;
            }
            return crc;
        }

        private static byte[] WithCrc(params byte[] body)
        {
            byte[] frame = new byte[body.Length + 2];
            Array.Copy(body, frame, body.Length);
            int crc = Crc(body, body.Length);
            frame[body.Length] = (byte)crc;
            frame[body.Length + 1] = (byte)(crc >> 8);
            return frame;
        }

        private static byte[] GoodReply(byte[] request, int value)
        {
            return WithCrc(request[0], request[1], 2, (byte)(value >> 8), (byte)value);
        }

        private static void SafeFailure(Session test, ActiveResult result, int requests)
        {
            Check(result.Status == "error", "expected error, got " + result.Status);
            Check(!result.CompleteDiagnostics, "failure marked complete");
            Check(!result.StartAuthorized && !result.PhysicalTrialVerified, "failure grants motion authorization");
            Check(test.Port.Requests.Count == requests, "requests continued or retried after failure");
            Check(test.Port.Opens == 1, "port reopened after failure");
            Check(test.Port.Closes == 1 && test.Port.Disposals == 1, "port was not closed and disposed exactly once");
            Check(!String.IsNullOrEmpty(result.Error), "failure did not retain its reason");
            Check(File.Exists(test.Settings.JsonReportPath) && File.Exists(test.Settings.TextReportPath), "failure reports missing");
        }

        private static void Test(string name, Action test)
        {
            try
            {
                test(); passed++; Console.WriteLine("PASS " + name);
                outcomes.Add("{\"name\":" + Quote(name) + ",\"status\":\"passed\"}");
            }
            catch (Exception error)
            {
                failed++; Console.WriteLine("FAIL " + name + ": " + error.Message);
                outcomes.Add("{\"name\":" + Quote(name) + ",\"status\":\"failed\",\"error\":" + Quote(error.Message) + "}");
            }
        }

        private static string Quote(string value)
        {
            return "\"" + (value ?? "").Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\r", "\\r").Replace("\n", "\\n").Replace("\t", "\\t") + "\"";
        }

        private static void CompleteAndFragmented()
        {
            using (Session test = new Session())
            {
                test.Port.ChunkSize = 1;
                test.Port.BeforeOpen = delegate {
                    Check(File.Exists(test.Settings.LogPath) && File.Exists(test.Settings.JsonReportPath) && File.Exists(test.Settings.TextReportPath), "evidence outputs not reserved before open");
                    Check(new FileInfo(test.Settings.LogPath).Length > 0, "metadata not flushed before COM open");
                };
                ActiveResult result = test.Run();
                Check(result.Status == "completed" && result.CompleteDiagnostics, "fragmented replies did not complete");
                Check(!result.StartAuthorized && !result.PhysicalTrialVerified, "diagnostics grants a physical trial or START");
                Check(result.Rpm.HasValue && result.Rpm.Value == 0, "valid zero RPM observation not preserved");
                Check(test.Port.Requests.Count == 37, "unexpected request count");
                string[] expected = { "h17", "h2", "i1", "i0", "i2", "i3", "i4", "i5", "i6", "i7", "i8", "i9", "i10", "i12", "i13", "i14", "h1", "h3", "h4", "h5", "h7", "h8", "h16", "h25", "h30", "i1", "i0", "i2", "i3", "i4", "i5", "i6", "i7", "i8", "i9", "h2", "h17" };
                for (int i = 0; i < expected.Length; i++)
                {
                    byte[] request = test.Port.Requests[i];
                    string actual = (request[1] == 3 ? "h" : "i") + Register(request);
                    Check(actual == expected[i], "request " + i + ": expected " + expected[i] + ", got " + actual);
                }
                Check(test.Port.Closes == 1 && test.Port.Disposals == 1, "successful session did not release port");
                string json = File.ReadAllText(test.Settings.JsonReportPath);
                Check(json.Contains("\"start_authorized\":false") && json.Contains("\"physical_trial_verified\":false"), "JSON safety flags missing");
                Check(json.Contains("\"rpm_snapshot\":0"), "JSON report did not preserve a valid zero RPM snapshot");
                Check(File.ReadAllText(test.Settings.TextReportPath).Length > 100, "human report empty");
                Check(File.ReadAllLines(test.Settings.LogPath).Length >= 76, "transaction evidence missing");
            }
        }

        private static void ProtocolFailure(string kind)
        {
            using (Session test = new Session())
            {
                byte[] sentReply = null;
                if (kind == "trailing_same_chunk") test.Port.ChunkSize = 256;
                test.Port.Reply = delegate(byte[] request, int index) {
                    byte[] reply;
                    if (kind == "crc") { reply = GoodReply(request, 0); reply[reply.Length - 1] ^= 1; }
                    else if (kind == "slave") reply = WithCrc(2, request[1], 2, 0, 0);
                    else if (kind == "function") reply = WithCrc(request[0], 4, 2, 0, 0);
                    else if (kind == "count") reply = WithCrc(request[0], request[1], 4, 0, 0, 0, 0);
                    else if (kind == "trailing_same_chunk" || kind == "trailing_fragment")
                    {
                        reply = new byte[8];
                        Array.Copy(GoodReply(request, 0), reply, 7);
                        reply[7] = 0xaa;
                    }
                    else reply = WithCrc(request[0], (byte)(request[1] | 0x80), 2);
                    sentReply = reply;
                    return reply;
                };
                ActiveResult result = test.Run();
                SafeFailure(test, result, 1);
                Check(!result.Rpm.HasValue, "protocol failure fabricated zero RPM");
                string log = File.ReadAllText(test.Settings.LogPath).ToLowerInvariant();
                Check(log.Contains("failure") || log.Contains("error"), "failure event absent from evidence");
                if (kind != "exception") Check(log.Contains("invalid") || log.Contains("\"valid\":false"), "invalid response absent from evidence");
                if (kind == "crc")
                {
                    string hex = BitConverter.ToString(sentReply).Replace('-', ' ').ToLowerInvariant();
                    Check(log.Contains(hex), "bad CRC raw reply omitted from log");
                }
            }
        }

        private static void InitialGate(int register, int badValue, int requests)
        {
            using (Session test = new Session())
            {
                test.Port.Reply = delegate(byte[] request, int index) {
                    int value = request[1] == 3 && Register(request) == register ? badValue : DefaultValue(request);
                    return GoodReply(request, value);
                };
                ActiveResult result = test.Run();
                SafeFailure(test, result, requests);
                Check(result.DoNotReconnect, "active watchdog/demand did not prohibit reconnection");
                Check(!result.Rpm.HasValue, "initial gate fabricated RPM");
            }
        }

        private static void WrongIdentity(bool firmware)
        {
            using (Session test = new Session())
            {
                int badRegister = firmware ? 0 : 1;
                test.Port.Reply = delegate(byte[] request, int index) {
                    return GoodReply(request, request[1] == 4 && Register(request) == badRegister ? 65535 : DefaultValue(request));
                };
                ActiveResult result = test.Run();
                SafeFailure(test, result, firmware ? 4 : 3);
                Check(!result.Rpm.HasValue, "identity failure fabricated RPM");
            }
        }

        private static void ChangedIdentityOrGate(string field)
        {
            using (Session test = new Session())
            {
                int target = field == "i1" ? 26 : field == "i0" ? 27 : field == "h2" ? 36 : field == "h17" ? 37 : 26 + Int32.Parse(field.Substring(1));
                test.Port.Reply = delegate(byte[] request, int index) {
                    return GoodReply(request, index == target ? DefaultValue(request) + 1 : DefaultValue(request));
                };
                ActiveResult result = test.Run();
                SafeFailure(test, result, target);
                Check(result.Rpm.HasValue && result.Rpm.Value == 0, "failed final validation erased or changed observed zero RPM");
                if (field == "h2" || field == "h17") Check(result.DoNotReconnect, "unsafe final gate did not prohibit reconnecting");
            }
        }

        private static void CancelBeforeOpen()
        {
            using (Session test = new Session())
            using (CancellationTokenSource cancellation = new CancellationTokenSource())
            {
                cancellation.Cancel();
                ActiveResult result = test.Run(cancellation.Token);
                Check(result.Status == "cancelled", "pre-cancel status");
                Check(test.Port.Opens == 0 && test.Port.Requests.Count == 0, "pre-cancel performed port I/O");
                Check(!result.Rpm.HasValue && !result.CompleteDiagnostics, "pre-cancel fabricated observations");
                Check(File.Exists(test.Settings.JsonReportPath), "pre-cancel report missing");
            }
        }

        private static void CancelDuringReply()
        {
            using (Session test = new Session())
            using (CancellationTokenSource cancellation = new CancellationTokenSource())
            {
                test.Port.ChunkSize = 1;
                test.Port.BeforeRead = delegate(int reads) { if (reads == 2) cancellation.Cancel(); };
                ActiveResult result = test.Run(cancellation.Token);
                Check(result.Status == "cancelled", "mid-reply cancellation status");
                Check(test.Port.Requests.Count == 1 && test.Port.ReplyReads == 2 && test.Port.Opens == 1, "I/O continued after cancellation");
                Check(test.Port.Closes == 1 && test.Port.Disposals == 1, "cancelled session did not release port");
                Check(!result.Rpm.HasValue && !result.CompleteDiagnostics, "cancelled session fabricated RPM");
                Check(File.Exists(test.Settings.JsonReportPath), "cancelled report missing");
            }
        }

        private static void ExactDeadline()
        {
            using (Session test = new Session())
            {
                test.Port.ChunkSize = 1;
                test.Port.ReadStepMs = 120;
                ActiveResult result = test.Run();
                SafeFailure(test, result, 1);
                Check(test.Port.ReplyReads <= 5, "byte trickle extended the fixed reply deadline");
                Check(test.Clock.Now <= test.Port.FirstWriteAtMs + 600, "reply timeout was reset by each fragment");
                Check(!result.Rpm.HasValue, "deadline error fabricated RPM");
            }
        }

        private static void TimeoutAtRpm()
        {
            using (Session test = new Session())
            {
                test.Port.ReadStepMs = 50;
                test.Port.Reply = delegate(byte[] request, int index) { return index == 16 ? null : GoodReply(request, DefaultValue(request)); };
                ActiveResult result = test.Run();
                SafeFailure(test, result, 16);
                Check(!result.Rpm.HasValue, "failed RPM read was represented as zero");
                Check(File.ReadAllText(test.Settings.JsonReportPath).Contains("\"rpm_snapshot\":null"), "JSON report fabricated zero RPM after a failed read");
            }
        }

        private static void NonzeroRpmAborts()
        {
            using (Session test = new Session())
            {
                test.Port.Reply = delegate(byte[] request, int index) {
                    return GoodReply(request, request[1] == 4 && Register(request) == 14 ? 126 : DefaultValue(request));
                };
                ActiveResult result = test.Run();
                SafeFailure(test, result, 16);
                Check(result.Rpm.HasValue && result.Rpm.Value == 126, "nonzero RPM observation was lost or represented as zero");
                Check(result.DoNotReconnect, "nonzero RPM did not prohibit reconnection");
                Check(File.ReadAllText(test.Settings.JsonReportPath).Contains("\"rpm_snapshot\":126"), "JSON report lost the nonzero RPM observation");
            }
        }

        private static void ZeroUidAborts()
        {
            using (Session test = new Session())
            {
                test.Port.Reply = delegate(byte[] request, int index) {
                    int register = Register(request);
                    return GoodReply(request, request[1] == 4 && register >= 3 && register <= 8 ? 0 : DefaultValue(request));
                };
                ActiveResult result = test.Run();
                SafeFailure(test, result, 12);
                Check(!result.Rpm.HasValue, "zero UID failure fabricated an RPM observation");
                Check(result.DoNotReconnect, "zero UID did not prohibit reconnection");
            }
        }

        private static void PrequeuedReplyAborts()
        {
            using (Session test = new Session())
            {
                byte[] stale = WithCrc(1, 3, 2, 0, 0);
                test.Port.Preload(stale);
                ActiveResult result = test.Run();
                SafeFailure(test, result, 0);
                Check(!result.Rpm.HasValue && result.DoNotReconnect, "unsolicited data did not leave RPM unknown and prohibit reconnecting");
                string log = File.ReadAllText(test.Settings.LogPath).ToLowerInvariant();
                Check(log.Contains("unsolicited_rx") && log.Contains("\"valid\":false"), "prequeued bytes not recorded as invalid unsolicited RX");
                Check(log.Contains(BitConverter.ToString(stale).Replace('-', ' ').ToLowerInvariant()), "prequeued raw reply missing from evidence");
            }
        }

        private static void CancelDuringInitialQuiet()
        {
            using (Session test = new Session())
            using (CancellationTokenSource cancellation = new CancellationTokenSource())
            {
                test.Port.BeforeQuietRead = delegate(int count) { if (count == 2) cancellation.Cancel(); };
                ActiveResult result = test.Run(cancellation.Token);
                Check(result.Status == "cancelled", "initial-quiet cancellation status");
                Check(test.Port.Opens == 1 && test.Port.Requests.Count == 0 && test.Port.Reads == 2, "initial-quiet cancellation transmitted or continued reading");
                Check(test.Port.Closes == 1 && test.Port.Disposals == 1, "initial-quiet cancellation did not release port");
                Check(!result.Rpm.HasValue && !result.CompleteDiagnostics && !result.StartAuthorized, "initial-quiet cancellation fabricated diagnostics");
                Check(File.Exists(test.Settings.JsonReportPath) && File.Exists(test.Settings.TextReportPath), "initial-quiet cancellation reports missing");
            }
        }

        private static void OutputUnavailable(bool existing, int pathIndex)
        {
            using (Session test = new Session())
            {
                string[] paths = { test.Settings.LogPath, test.Settings.JsonReportPath, test.Settings.TextReportPath };
                if (existing) File.WriteAllText(paths[pathIndex], "existing evidence");
                else
                {
                    string missing = Path.Combine(test.DirectoryPath, "does-not-exist", "evidence.jsonl");
                    if (pathIndex == 0) test.Settings.LogPath = missing;
                    if (pathIndex == 1) test.Settings.JsonReportPath = missing;
                    if (pathIndex == 2) test.Settings.TextReportPath = missing;
                }
                ActiveResult result = test.Run();
                Check(result.Status == "error", "unavailable output did not fail");
                Check(test.Port.Opens == 0 && test.Port.Requests.Count == 0 && test.Port.Reads == 0, "port opened before evidence was reserved");
                if (existing) Check(File.ReadAllText(paths[pathIndex]) == "existing evidence", "existing evidence overwritten");
            }
        }

        private static void InvalidSettings()
        {
            using (Session test = new Session())
            {
                test.Settings.Slave = 0;
                ActiveResult result = test.Run();
                Check(result.Status == "error" && test.Port.Opens == 0 && test.Port.Requests.Count == 0, "broadcast address accepted");
            }
        }

        private static void OpenFailure()
        {
            using (Session test = new Session())
            {
                test.Port.ThrowOnOpen = true;
                ActiveResult result = test.Run();
                Check(result.Status == "error" && test.Port.Opens == 1 && test.Port.Requests.Count == 0, "failed open was retried or transmitted");
                Check(!result.Rpm.HasValue && File.Exists(test.Settings.JsonReportPath), "open failure report/unknown RPM missing");
            }
        }

        private static void ConcurrentOwnership()
        {
            using (Session first = new Session())
            using (Session second = new Session())
            using (ManualResetEvent reading = new ManualResetEvent(false))
            using (ManualResetEvent release = new ManualResetEvent(false))
            {
                ActiveResult firstResult = null;
                Exception workerError = null;
                first.Port.BeforeRead = delegate(int count) {
                    if (count == 1)
                    {
                        reading.Set();
                        Check(release.WaitOne(5000), "concurrent test release timed out");
                    }
                };
                Thread worker = new Thread(delegate() {
                    try { firstResult = first.Run(); }
                    catch (Exception error) { workerError = error; }
                });
                worker.Start();
                try
                {
                    Check(reading.WaitOne(5000), "first operation did not start");
                    ActiveResult secondResult = ActiveDiagnostics.Run(second.Settings, first.Port, CancellationToken.None, null, second.Clock);
                    Check(secondResult.Status == "error" && !secondResult.CompleteDiagnostics, "second simultaneous owner was accepted");
                    Check(first.Port.Opens == 1 && first.Port.Requests.Count == 1 && first.Port.Closes == 0, "second operation changed the outstanding request or closed its port");
                }
                finally
                {
                    release.Set();
                    Check(worker.Join(5000), "first operation did not finish");
                }
                Check(workerError == null, "first operation threw: " + workerError);
                Check(firstResult != null && firstResult.CompleteDiagnostics, "simultaneous rejected owner broke the original operation");
                Check(first.Port.Opens == 1 && first.Port.Requests.Count == 37, "concurrent owner caused serial retries");
            }
        }

        private static void SerialAdapterWriteGuard()
        {
            using (Session test = new Session())
            using (SerialActivePort port = new SerialActivePort(test.Settings))
            {
                List<byte[]> forbidden = new List<byte[]>();
                foreach (byte function in new byte[] { 0, 5, 6, 15, 16, 23 })
                    forbidden.Add(WithCrc(1, function, 0, 17, 0, 1));
                forbidden.Add(WithCrc(0, 3, 0, 17, 0, 1));
                forbidden.Add(WithCrc(1, 3, 0, 20, 0, 1));
                forbidden.Add(WithCrc(1, 3, 0, 17, 0, 2));
                byte[] badCrc = WithCrc(1, 3, 0, 17, 0, 1);
                badCrc[7] ^= 1;
                forbidden.Add(badCrc);
                foreach (byte[] frame in forbidden)
                {
                    Check(!ActiveDiagnostics.AllowedRequest(frame, 0, frame.Length), "unsafe direct frame was admitted");
                    bool guarded = false;
                    try { port.Write(frame, 0, frame.Length); }
                    catch (InvalidOperationException error) { guarded = error.Message.Contains("FC03/FC04"); }
                    Check(guarded, "adapter did not reject unsafe frame before SerialPort.Write");
                }
                Check(ActiveDiagnostics.AllowedRequest(WithCrc(1, 3, 0, 17, 0, 1), 0, 8), "valid fixed-plan request unexpectedly rejected");
            }
        }

        public static int Run(string reportPath)
        {
            passed = failed = 0;
            outcomes.Clear();
            Test("complete fixed snapshot and fragmented replies", CompleteAndFragmented);
            foreach (string kind in new string[] { "crc", "slave", "function", "count", "exception", "trailing_same_chunk", "trailing_fragment" })
            {
                string captured = kind;
                Test("reject " + captured, delegate { ProtocolFailure(captured); });
            }
            Test("watchdog active blocks all later reads", delegate { InitialGate(17, 0x0503, 1); });
            Test("stale demand blocks snapshot", delegate { InitialGate(2, 1, 2); });
            Test("wrong product", delegate { WrongIdentity(false); });
            Test("wrong firmware", delegate { WrongIdentity(true); });
            foreach (string field in new string[] { "i1", "i0", "i2", "i3", "i4", "i5", "i6", "i7", "i8", "i9", "h2", "h17" })
            {
                string captured = field;
                Test("changed final " + captured, delegate { ChangedIdentityOrGate(captured); });
            }
            Test("cancel before open", CancelBeforeOpen);
            Test("cancel during fragmented reply", CancelDuringReply);
            Test("trickled reply cannot extend deadline", ExactDeadline);
            Test("failed RPM remains unknown", TimeoutAtRpm);
            Test("nonzero RPM aborts immediately", NonzeroRpmAborts);
            Test("all-zero UID aborts after signature capture", ZeroUidAborts);
            Test("prequeued valid-looking reply aborts before TX", PrequeuedReplyAborts);
            Test("cancel during initial quiet before first TX", CancelDuringInitialQuiet);
            for (int i = 0; i < 3; i++)
            {
                int captured = i;
                Test("existing output prevents open " + i, delegate { OutputUnavailable(true, captured); });
                Test("missing output directory prevents open " + i, delegate { OutputUnavailable(false, captured); });
            }
            Test("broadcast address forbidden", InvalidSettings);
            Test("open failure has no retries", OpenFailure);
            Test("one outstanding request per port", ConcurrentOwnership);
            Test("serial adapter rejects direct unsafe writes", SerialAdapterWriteGuard);
            Console.WriteLine(passed + " passed; " + failed + " failed");
            if (!String.IsNullOrEmpty(reportPath))
            {
                using (FileStream file = new FileStream(reportPath, FileMode.CreateNew, FileAccess.Write, FileShare.Read))
                using (StreamWriter writer = new StreamWriter(file, new UTF8Encoding(false)))
                    writer.Write("{\"suite\":\"EC116 active read-only diagnostics\",\"passed\":" + passed + ",\"failed\":" + failed + ",\"tests\":[" + String.Join(",", outcomes.ToArray()) + "]}\n");
            }
            return failed == 0 ? 0 : 1;
        }

        public static int Main(string[] args) { return Run(args.Length == 0 ? null : args[0]); }
    }
}
