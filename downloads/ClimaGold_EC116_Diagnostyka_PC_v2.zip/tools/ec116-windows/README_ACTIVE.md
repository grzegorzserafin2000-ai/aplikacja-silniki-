# Single-adapter EC116 PC diagnostics

This is a separate entry point from the passive recorder in `Ec116Helper.cs`.
It is a fixed FC03/FC04 master for the operator's initial, secured stationary
bench context, with no motor/configuration commands or production unlock.
Read requests can renew an existing communication watchdog. The confirmation
screen and raw report describe that effect; no read-only neutrality is claimed.

Build from the repository root with a .NET Framework-compatible C# compiler:

```sh
mcs -target:winexe -platform:anycpu -langversion:7 -warnaserror -r:System.Windows.Forms -r:System.Drawing -main:ClimaGold.Ec116.ActiveProgram -win32icon:windows/assets/climagold_dark.ico -out:EC116_DIAGNOSTYKA_PC_v2.exe tools/ec116-windows/ActiveDiagnostics.cs tools/ec116-windows/ActiveDiagnosticsTests.cs tools/ec116-windows/ActiveDiagnosticsForm.cs
```

The executable uses Windows' .NET Framework runtime and requires no Python or
adjacent files. No administrator privilege, network request or install step is
part of the application. COM is opened only after an explicit diagnostic click.

```text
EC116_DIAGNOSTYKA_PC_v2.exe --self-test --self-test-report self-tests.json
EC116_DIAGNOSTYKA_PC_v2.exe --smoke-test --smoke-report smoke.json --smoke-image preview.png
```

The 42 tests cover complete and fragmented replies, CRC/exception/function/
address/length failures, initial and trailing noise, non-extending deadlines,
cancellation, read/write whitelist, no retries, output protection, shared-port
ownership, motion abort and final unit-signature changes. They inject serial
I/O and a clock; no physical port or motor is used. GUI smoke opens the window
without running diagnostics. Linux/Mono checks do not establish native Windows
operation or firmware-specific motion, STOP or watchdog behavior.

```sh
python3 tools/package_ec116_pc.py EC116_DIAGNOSTYKA_PC_v2.exe
```

Three evidence files are reserved before opening COM. Disk failures can leave
incomplete artifacts or a report from before a later flush/close failure; the
GUI prominently reports the returned failure even when an earlier report can
be read. Diagnostic reports never constitute a physical movement qualification.
