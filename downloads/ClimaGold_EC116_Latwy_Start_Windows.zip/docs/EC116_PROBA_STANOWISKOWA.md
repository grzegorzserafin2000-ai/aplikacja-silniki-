# Próba kwalifikacyjna EC116 / firmware 21.00

**Egzemplarz:** GR20V-4IP.Z8.AR, P/N 192648, i1=0x0101, i0=2100.
**Stan:** procedura i kod przygotowane do weryfikacji; nie wykonano próby
na silniku. Produkcyjny START pozostaje zablokowany. Próba wymaga osoby
przy fizycznym stanowisku; środowisko chmurowe nie ma dostępu do napędu.

## 1. Warunki przed próbą

Serwisant przygotowuje osłonięty wentylator i sprawdza rzeczywiste zatrzymanie
sprzętowe niezależne od telefonu, Carela i RS485. Zapisuje sposób odłączenia
energii, zmierzony wybieg oraz graniczny czas przerwania próby. Ten sposób
nie został jeszcze potwierdzony przez użytkownika. Nie zastępujemy go D1:
użytkownik zgłosił brak fizycznego zacisku D1 w tym egzemplarzu.

Sterowanie podczas kwalifikacji prowadzi działający Carel lub narzędzie
serwisowe zatwierdzone dla tego napędu. Aplikacja nie jest drugim masterem.
Kandydat `Ec116TrialController` nie jest obejściem blokady: uruchomienie
produkcyjne wymaga odrębnie zweryfikowanej kwalifikacji konkretnego egzemplarza.

Pierwsza część próby jest pasywna: analizator musi mieć fizycznie zablokowany
TX i obserwować całą magistralę. Oprogramowanie rejestrujące nie zastępuje
izolacji i blokady nadawania urządzenia pomiarowego.

## 2. Co dokładnie sprawdzamy

Poniższe adresy to **kandydat z E076**, a nie już potwierdzona mapa zapisów FW21.
Najpierw sprawdzamy je z aktualną mapą producenta albo zapisem działającego
Carela. `SpeedReq_ZA` i `FrcOff_ZA` są nazwami biblioteki, nie adresami RTU.
Nie przypisujemy `FrcOff_ZA` arbitralnie do h1.

| Etap kandydata | Polecenie / pomiar | Warunek przejścia |
|---|---|---|
| Tożsamość | FC04: i0, i1, i2, i3–i8, i9 | FW21, produkt 0101; zapisana sześciowyrazowa sygnatura, ID i indeks zestawu parametrów |
| Migawka | FC03: h1,h2,h3,h4,h5,h7,h8,h16,h17,h25,h30 | h1=h2=0, h4=3, h5=1570, h17=0; minimum, start po resecie i pasma wykluczeń nie mogą podać niezerowego zadania |
| Dostęp | Jeśli wymagany: PIN 10 w h0, kontrola poziomu dostępu | Potwierdzona dla modelu obsługa i wymagany poziom; brak automatycznych retransmisji |
| Przygotowanie | Tymczasowe h5=0, kontrola; następnie h17=0x0503, kontrola | Trwała migawka przed pierwszym zapisem; rzeczywiste 0 RPM; oba odczyty zgodne |
| Zadanie | h2: dodatnie procenty w potwierdzonym CM=3 | Pierwsze dodatnie zadanie może uruchomić wirnik; dopiero po przygotowaniu ochrony |
| STOP | Najpierw h2=0, następnie odczyt h2 i i14/statusów | ≥3 kolejne poprawne próbki 0 RPM przez ≥600 ms oraz niezależnie zmierzony postój |
| Odtworzenie | h17=0 i odczyt; **dopiero potem** h5=1570 i odczyt | Potwierdzony postój, zerowe h2, kontrola całej migawki i brak samoczynnego wznowienia |

Nie zapisujemy h1, h3, h4, h20, h25, funkcji wejść ani parametrów kalibracji.
Nie używamy resetów 9095/2143. Adres i transmisja pozostają bez zmian.
h4=3 wyłącza Buscon Enable, więc h1=0 nie jest dowodem skutecznego STOP.
Przy h5=1570 nie wolno uzbroić trybu3 watchdoga jako rzekomo zerowej nastawy.

## 3. Jedna sesja kwalifikacyjna

1. **Zapis Carela.** Zarejestruj zwykły START, dwie dopuszczone nastawy,
   zero zadania i STOP. Ustal rzeczywiste funkcje/adresy/wartości oraz kolejność
   ramek. Obroty zapisuj również niezależnym obrotomierzem. Wyłączenie samego
   modułu `En_ZA` nie jest STOP. Jeśli mapowanie pozostaje nieustalone, nie
   przechodź do eksperymentalnych zapisów kandydata.
2. **Identyfikacja i skala.** Zapisz tabliczkę, i0/i1, i2/i9 i wszystkie sześć
   słów i3–i8 przed i po sesji. Potwierdź skalę 10–100% oraz ograniczenie
   prędkości. h8=4700 z wcześniejszego raportu nie jest automatycznie limitem
   fizycznym: Carel opisuje maksimum jako mniejszą wartość FW_MaxSpeed_HR20
   i MaxSpeed_user_HR8. Dodatkowy limit odczytuj wyłącznie po potwierdzeniu
   mapy; nie zmieniaj go. Nie wykonuj pełnej prędkości w ciemno.
3. **STOP przy małej prędkości.** Po potwierdzeniu mapy i przygotowaniu
   zerowego fallbacku wykonaj krótką, nadzorowaną próbę przy najmniejszej
   dopuszczonej prędkości. Zmierz odliczanie od pierwszego dodatniego zadania,
   reakcję na STOP, odczyt zwrotny h2 i czas do rzeczywistego postoju. ACK
   zapisu nie wystarcza. Brak RPM pozostaje stanem nieznanym, nie zerem.
4. **Utrata komunikacji.** W osobnym przebiegu potwierdź dodatnie zadanie
   i rzeczywisty ruch, a potem w kontrolowany sposób zatrzymaj nadawanie
   wszystkich masterów. Nie wysyłaj nawet odczytów diagnostycznych; mogą
   podtrzymać watchdog. Rejestrator nadal słucha, a obrotomierz mierzy bez
   MODBUS. Zmierz osobno reakcję watchdoga i wybieg. Termin niezależnego
   przerwania próby ustala się przed uruchomieniem. Użycie wyłącznika podczas
   tej części oznacza niezaliczenie automatycznego STOP. Pięć sekund watchdoga
   nie jest gwarancją mechanicznego postoju w pięć sekund.
5. **Bezpieczny powrót.** Stare dodatnie h2 może pozostać w pamięci, a pierwszy
   odczyt po powrocie łączności może odnowić watchdog i wznowić ruch.
   Powrót wymaga wcześniej ustalonego niezależnego zatrzymania/inhibicji albo
   zweryfikowanej procedury bezpiecznego cyklu zasilania. Nie wykonuj
   niechronionego automatycznego odczytu. Nie zakładaj, że przy odłączonym
   zasilaniu głównym elektronika nadal będzie odpowiadać.
   Walidator rozróżnia `independent_inhibit` i `safe_power_cycle`. W drugim
   przypadku wymagane są osobne czasy wyłączenia, włączenia i gotowości,
   dowód 0 RPM przed wyłączeniem i po ponownym włączeniu oraz pierwszy
   odczyt h2=0 przed zapisami. Cykl zasilania nie może zastąpić dowodu,
   że watchdog zatrzymał napęd podczas wcześniejszej ciszy RS485.
6. **Odtworzenie i zakończenie.** Po odzyskaniu sterowania potwierdź zerowe
   h2 i stabilny postój. Przywróć oraz odczytaj h17=0, następnie h5=1570.
   Jeśli wynik wyłączenia watchdoga jest niepewny, nie odtwarzaj niezerowego
   h5. Porównaj migawkę i tożsamość; sprawdź brak wznowienia po zakończeniu
   ochrony odzyskiwania. Po niepewnym STOP pozostaw wynik niepewny i użyj
   niezależnego zatrzymania. Nie ponawiaj automatycznie zapisów.

## 4. Pliki i narzędzia

Pracuj w osobnym katalogu sesji. Skopiuj do niego
`docs/ec116-bench/manifest.example.json` jako `manifest.json` oraz
`commissioning-checklist.csv`. Przykładowe czasy w manifeście nie są wynikiem
pomiaru ani zalecanym czasem postoju; zastąp je rzeczywistymi, zsynchronizowanymi
czasami monotonicznymi i wcześniej ustalonym limitem.

Opcjonalny zapis bajtów z izolowanego odbiornika, po ustaleniu właściwego portu:

Rejestrator wymaga komputera z Pythonem 3.10+ i pakietem `pyserial`.
Walidator działa na standardowej bibliotece Pythona. W Windows podaj
właściwy port, np. `COM3`, zamiast `/dev/ttyUSB0`. To nie jest sterownik
silnika i nie zastępuje zatwierdzonego narzędzia używanego do próby.

```sh
python3 tools/ec116_bench.py record --port /dev/ttyUSB0 --baud 9600 --frame 8N2 --seconds 120 --output sesja/raw.jsonl
```

To polecenie **nie wysyła MODBUS**, również STOP. Plik `raw.jsonl` zawiera
odebrane fragmenty bez wiarygodnego oznaczenia kierunku; sam nie przejdzie
walidacji. Do `trace.jsonl` potrzebny jest wyeksportowany, poprawnie rozdzielony
zapis TX/RX z CRC i czasami, a do `tachometer.csv` niezależne próbki:

```csv
t_ms,rpm
```

Przykład **formatu**, nie wynik nowej próby:

```jsonl
{"t_ms":0,"event":"capture_start"}
{"t_ms":10,"direction":"tx","hex":"e7 04 00 01 00 01 76 0c"}
{"t_ms":40,"direction":"rx","hex":"e7 04 02 01 01 70 b6"}
{"t_ms":500,"event":"heartbeat"}
{"t_ms":1000,"event":"capture_end"}
```

Kierunek TX/RX musi wynikać z rejestratora, nie z przypuszczenia na podstawie
identycznych ramek zapisu i echa. Podczas ciszy ciągłość odbioru dokumentują
znaczniki `heartbeat` co najwyżej co 1000 ms; nie są to telegramy MODBUS.

Dołącz nagranie/przebieg próby, wynik funkcjonalnego sprawdzenia niezależnego
zatrzymania i dowód bezpiecznego odzyskania sterowania. Wszystkie pliki
wskazane w manifeście muszą pochodzić z tej rzeczywistej sesji, nie symulacji.
Uzupełnij checklistę zmierzonymi wartościami i odnośnikami do dowodów.

```sh
python3 tools/ec116_bench.py validate sesja/manifest.json > sesja/validation.json
```

`review_ready=true` oznacza kompletność materiału do przeglądu inżynierskiego.
`start_authorized` pozostaje **false**. Walidator nie wykonuje próby fizycznej,
nie zatwierdza zabezpieczenia i nie odblokowuje aplikacji.
Manifest wymaga rzeczywistych `unit.baud`, `unit.frame`, sześciu słów
`unit.device_signature`, `unit.parameter_set_id` i `unit.parameter_set_index`,
zgodnych ze świeżymi ramkami na początku i końcu. Pojedyncze słowo sygnatury
może być zerem; sześć zer nie stanowi identyfikacji egzemplarza. Pusty szablon
celowo nie przechodzi walidacji. Zapis FC06 i FC16 jest dekodowany i sprawdzany,
w tym kolejność odczytów kontrolnych przed uzbrojeniem watchdoga.

Dla `safe_power_cycle` wpisz `power_off_ms`, `power_on_ms`, `ready_ms` oraz
`evidence_artifact`. Dla `independent_inhibit` wpisz `inhibit_start_ms`,
`inhibit_end_ms` i dowód utrzymywanej inhibicji. Nie przepisuj jednego sposobu
jako drugiego. Niezależny automatyczny postój musi być potwierdzony przed
rozpoczęciem obu procedur odzyskania. Po powrocie zasilania wymagane są
co najmniej trzy niezależne próbki 0 RPM przez 600 ms, zebrane przed pierwszą
ramką. Ich brak oznacza niezaliczoną procedurę cyklu zasilania.
Docelowe dopuszczenie profilu wymaga przeglądu protokołu i powiązania jego
SHA-256 z sześcioma słowami sygnatury egzemplarza. Obecna kwalifikacja
produkcyjna jest pusta; plik JSON ani checkbox nie zastępują tego kroku.
Kwalifikacja wiąże także skalę h8, pełną rampę h25 oraz ID i indeks zestawu
parametrów. Zmiana h8 nie może zwiększyć rzeczywistych obrotów pod tym samym
już zatwierdzonym procentem. Odrębnie zatwierdzany jest maksymalny procent
i procedura odzyskania; brak tych danych utrzymuje blokadę.

**Ostatni wymagany krok:** osoba przy silniku wykonuje powyższą sesję, zapisuje
pozytywne wyniki STOP, pełnej ciszy RS485, bezpiecznego powrotu i odtworzenia,
a materiał przechodzi przegląd dla tego P/N, firmware i sygnatury. Dopiero taki
wynik pozwala włączyć właściwy profil; sama zmiana zakresu firmware, checkbox
lub wynik testów programu nie spełnia tego warunku.

## Weryfikacja oprogramowania

Kod obejmuje sterowanie kandydackie 10–100%, odliczanie czasu, pracę ciągłą
z czasem trwania, STOP, pomiar RPM, dziennik przed zapisem i obsługę utraty
potwierdzenia. Testy referencyjnego silnika symulują również odnowienie
watchdoga i możliwość wznowienia starego dodatniego zadania po pierwszym
niechronionym odczycie. Nie są próbą fizyczną firmware21.

Zestawy Java oraz testy Pythona należy uruchomić odpowiednio:

```sh
bash tests/run.sh
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -p 'test_ec116_bench.py' -v
```

Kodowania adresów, adresu urządzenia ani parametrów transmisji w teście nie
zmieniono. Nie przebudowano interfejsu ani APK. Publiczne wejście kontrolera
nie wykona żadnego I/O ruchowego, dopóki dane kwalifikacji pozostają puste.
