using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Ports;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace ClimaGold.Ec116
{
    // Deliberately exposes no method that can transmit serial data.
    public interface IReceiveOnlyPort : IDisposable
    {
        void Open();
        int Read(byte[] buffer, int offset, int count);
        void Close();
    }

    public interface IRecordingClock
    {
        void Restart();
        long Milliseconds { get; }
    }

    public sealed class RecordingClock : IRecordingClock
    {
        private readonly Stopwatch clock = new Stopwatch();
        public void Restart() { clock.Restart(); }
        public long Milliseconds { get { return clock.ElapsedMilliseconds; } }
    }

    public sealed class SerialReceiver : IReceiveOnlyPort
    {
        private readonly SerialPort port;
        public SerialReceiver(string name, int baud, string frame)
        {
            Parity parity = frame[1] == 'E' ? Parity.Even : frame[1] == 'O' ? Parity.Odd : Parity.None;
            port = new SerialPort(name, baud, parity, 8, frame[2] == '2' ? StopBits.Two : StopBits.One);
            // Set all control lines before opening. Physical TX isolation is still required.
            port.Handshake = Handshake.None;
            port.DtrEnable = false;
            port.RtsEnable = false;
            port.ReadTimeout = 100;
        }
        public void Open() { port.Open(); }
        public int Read(byte[] buffer, int offset, int count) { return port.Read(buffer, offset, count); }
        public void Close() { if (port.IsOpen) port.Close(); }
        public void Dispose() { port.Dispose(); }
    }

    public sealed class RecordingSettings
    {
        public string PortName;
        public int Baud;
        public string Frame;
        public int Seconds;
        public string OutputPath;
        public void Validate()
        {
            if (String.IsNullOrWhiteSpace(PortName)) throw new ArgumentException("Wybierz port odbiornika.");
            if (Array.IndexOf(new int[] { 4800, 9600, 14400, 19200, 38400, 57600, 115200 }, Baud) < 0)
                throw new ArgumentException("Nieobsługiwana prędkość transmisji.");
            if (Array.IndexOf(new string[] { "8N1", "8N2", "8E1", "8E2", "8O1", "8O2" }, Frame) < 0)
                throw new ArgumentException("Nieobsługiwany format transmisji.");
            if (Seconds < 10 || Seconds > 3600) throw new ArgumentException("Czas zapisu: od 10 do 3600 sekund.");
            if (String.IsNullOrWhiteSpace(OutputPath)) throw new ArgumentException("Brak ścieżki zapisu.");
        }
    }

    public sealed class RecordingResult
    {
        public string Status;
        public string Error;
        public long ByteCount;
        public long ElapsedMs;
        public string OutputPath;
    }

    public static class Json
    {
        public static string Quote(string value)
        {
            StringBuilder text = new StringBuilder("\"");
            foreach (char c in value ?? "")
            {
                switch (c)
                {
                    case '"': text.Append("\\\""); break;
                    case '\\': text.Append("\\\\"); break;
                    case '\n': text.Append("\\n"); break;
                    case '\r': text.Append("\\r"); break;
                    case '\t': text.Append("\\t"); break;
                    default:
                        if (c < 32) text.Append("\\u" + ((int)c).ToString("x4"));
                        else text.Append(c);
                        break;
                }
            }
            return text.Append('"').ToString();
        }
    }

    public static class PassiveRecorder
    {
        private static void Emit(StreamWriter writer, IRecordingClock clock, string kind, string fields)
        {
            writer.WriteLine("{\"t_ms\":" + clock.Milliseconds + ",\"event\":" + Json.Quote(kind) + fields + "}");
        }

        public static RecordingResult Record(RecordingSettings settings, IReceiveOnlyPort receiver,
            CancellationToken cancellation, Action<long, long> progress, IRecordingClock suppliedClock = null)
        {
            settings.Validate();
            IRecordingClock clock = suppliedClock ?? new RecordingClock();
            RecordingResult result = new RecordingResult { Status = "completed", Error = "", OutputPath = settings.OutputPath };
            // CreateNew refuses to overwrite evidence, before the COM port can be opened.
            using (FileStream file = new FileStream(settings.OutputPath, FileMode.CreateNew, FileAccess.Write, FileShare.Read))
            using (StreamWriter writer = new StreamWriter(file, new UTF8Encoding(false)))
            {
                writer.NewLine = "\n";
                writer.AutoFlush = true;
                bool started = false;
                bool connectionOpened = false;
                clock.Restart();
                try
                {
                    cancellation.ThrowIfCancellationRequested();
                    receiver.Open();
                    connectionOpened = true;
                    clock.Restart();
                    EmitStart(writer, clock, settings, true);
                    started = true;
                    long heartbeatAt = 0;
                    byte[] buffer = new byte[4096];
                    while (clock.Milliseconds < settings.Seconds * 1000L)
                    {
                        cancellation.ThrowIfCancellationRequested();
                        int count = 0;
                        try { count = receiver.Read(buffer, 0, buffer.Length); }
                        catch (TimeoutException) { }
                        if (count < 0 || count > buffer.Length) throw new IOException("Nieprawidłowa liczba odebranych bajtów.");
                        if (count > 0)
                        {
                            string hex = BitConverter.ToString(buffer, 0, count).Replace('-', ' ').ToLowerInvariant();
                            Emit(writer, clock, "raw_chunk", ",\"direction\":\"observed\",\"hex\":" + Json.Quote(hex));
                            result.ByteCount += count;
                        }
                        if (clock.Milliseconds - heartbeatAt >= 500)
                        {
                            Emit(writer, clock, "heartbeat", "");
                            heartbeatAt = clock.Milliseconds;
                            if (progress != null) progress(clock.Milliseconds, result.ByteCount);
                        }
                    }
                    if (cancellation.IsCancellationRequested) result.Status = "cancelled";
                }
                catch (OperationCanceledException) { result.Status = "cancelled"; }
                catch (Exception error)
                {
                    result.Status = "error";
                    result.Error = error.GetType().Name + ": " + error.Message;
                }
                finally
                {
                    try { receiver.Close(); }
                    catch (Exception error)
                    {
                        result.Status = "error";
                        result.Error += (result.Error.Length > 0 ? "; " : "") + "Zamknięcie portu: " + error.Message;
                    }
                    try { receiver.Dispose(); }
                    catch (Exception error)
                    {
                        result.Status = "error";
                        result.Error += (result.Error.Length > 0 ? "; " : "") + "Zwolnienie portu: " + error.Message;
                    }
                }
                result.ElapsedMs = clock.Milliseconds;
                if (!started) EmitStart(writer, clock, settings, connectionOpened);
                Emit(writer, clock, "capture_end", ",\"read_only\":true,\"recording_status\":" + Json.Quote(result.Status)
                    + ",\"completed\":" + (result.Status == "completed" ? "true" : "false")
                    + ",\"interrupted\":" + (result.Status == "completed" ? "false" : "true")
                    + ",\"byte_count\":" + result.ByteCount + ",\"error\":" + Json.Quote(result.Error)
                    + ",\"direction_verified\":false,\"physical_trial_verified\":false,\"start_authorized\":false");
            }
            return result;
        }

        private static void EmitStart(StreamWriter writer, IRecordingClock clock, RecordingSettings settings, bool opened)
        {
            Emit(writer, clock, "capture_start", ",\"read_only\":true,\"port\":" + Json.Quote(settings.PortName)
                + ",\"baud\":" + settings.Baud + ",\"frame\":" + Json.Quote(settings.Frame)
                + ",\"connection_opened\":" + (opened ? "true" : "false")
                + ",\"scope\":\"passive bytes; direction unverified\",\"start_authorized\":false");
        }
    }

    public static class SessionFiles
    {
        private static Stream Template(string diskPath, string resource)
        {
            if (File.Exists(diskPath)) return new FileStream(diskPath, FileMode.Open, FileAccess.Read, FileShare.Read);
            Stream embedded = Assembly.GetExecutingAssembly().GetManifestResourceStream(resource);
            if (embedded == null) throw new FileNotFoundException("Brak dołączonego szablonu lub instrukcji. Pobierz ponownie kompletny program EC116.");
            return embedded;
        }

        public static void CopyNew(string source, string destination)
        {
            using (FileStream input = new FileStream(source, FileMode.Open, FileAccess.Read, FileShare.Read))
            using (FileStream output = new FileStream(destination, FileMode.CreateNew, FileAccess.Write, FileShare.Read))
                input.CopyTo(output);
        }

        public static string Create(string parent, string templates)
        {
            string manifest = Path.Combine(templates, "manifest.example.json");
            string checklist = Path.Combine(templates, "commissioning-checklist.csv");
            if (!Directory.Exists(parent)) throw new DirectoryNotFoundException("Wybrany folder nie istnieje.");
            string path = Path.Combine(parent, "EC116_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + "_" + Guid.NewGuid().ToString("N").Substring(0, 8));
            if (Directory.Exists(path)) throw new IOException("Folder sesji już istnieje. Wybierz ponownie miejsce zapisu.");
            Directory.CreateDirectory(path);
            try
            {
                using (Stream input = Template(manifest, "ClimaGold.manifest.json"))
                using (FileStream output = new FileStream(Path.Combine(path, "manifest.json"), FileMode.CreateNew, FileAccess.Write, FileShare.Read)) input.CopyTo(output);
                using (Stream input = Template(checklist, "ClimaGold.checklist.csv"))
                using (FileStream output = new FileStream(Path.Combine(path, "commissioning-checklist.csv"), FileMode.CreateNew, FileAccess.Write, FileShare.Read)) input.CopyTo(output);
            }
            catch (Exception error) { throw new IOException("Nie udało się skopiować wszystkich szablonów. Folder: " + path, error); }
            return path;
        }

        public static string Instructions(string diskPath)
        {
            using (Stream input = Template(diskPath, "ClimaGold.instructions.md"))
            using (StreamReader reader = new StreamReader(input, Encoding.UTF8)) return reader.ReadToEnd();
        }
    }

    public sealed class BenchForm : Form
    {
        private readonly Color orange = Color.FromArgb(245, 139, 37);
        private readonly TextBox folder = new TextBox();
        private readonly ComboBox port = new ComboBox();
        private readonly ComboBox baud = new ComboBox();
        private readonly ComboBox frame = new ComboBox();
        private readonly NumericUpDown seconds = new NumericUpDown();
        private readonly CheckBox isolated = new CheckBox();
        private readonly Button start = new Button();
        private readonly Button cancel = new Button();
        private readonly Label status = new Label();
        private readonly Label outcome = new Label();
        private readonly BackgroundWorker worker = new BackgroundWorker();
        private readonly List<Control> idleControls = new List<Control>();
        private CancellationTokenSource cancellation;
        private string sessionPath;
        private string recordingPath;
        private bool closingAfterCapture;

        public BenchForm()
        {
            Text = "Clima Gold — próba EC116";
            BackColor = Color.FromArgb(20, 20, 20);
            ForeColor = Color.WhiteSmoke;
            Font = new Font("Segoe UI", 10F);
            AutoScaleMode = AutoScaleMode.Dpi;
            ClientSize = new Size(890, 790);
            MinimumSize = new Size(840, 760);
            StartPosition = FormStartPosition.CenterScreen;
            TableLayoutPanel page = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 9, Padding = new Padding(22), AutoScroll = true };
            page.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            page.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
            page.RowStyles.Add(new RowStyle(SizeType.Absolute, 62));
            page.RowStyles.Add(new RowStyle(SizeType.Absolute, 125));
            page.RowStyles.Add(new RowStyle(SizeType.Absolute, 33));
            page.RowStyles.Add(new RowStyle(SizeType.Absolute, 50));
            page.RowStyles.Add(new RowStyle(SizeType.Absolute, 80));
            page.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
            page.RowStyles.Add(new RowStyle(SizeType.Absolute, 90));
            page.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            Controls.Add(page);
            page.Controls.Add(LabelOf("CLIMA GOLD   /   EC116", 20, orange), 0, 0);
            page.Controls.Add(LabelOf("GR20V-4IP.Z8.AR · P/N 192648 · firmware 21.00\nPrzygotowanie materiału z próby. Program nie steruje silnikiem ani nie odblokowuje START.", 10, Color.WhiteSmoke), 0, 1);

            TableLayoutPanel sessions = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3 };
            sessions.RowStyles.Add(new RowStyle(SizeType.Absolute, 25));
            sessions.RowStyles.Add(new RowStyle(SizeType.Absolute, 32));
            sessions.RowStyles.Add(new RowStyle(SizeType.Absolute, 51));
            sessions.Controls.Add(LabelOf("1. Utwórz osobny folder sesji", 11, orange), 0, 0);
            folder.ReadOnly = true;
            folder.Dock = DockStyle.Fill;
            folder.Text = "Tu pojawi się folder z szablonem manifestu i checklistą.";
            StyleInput(folder);
            sessions.Controls.Add(folder, 0, 1);
            FlowLayoutPanel sessionButtons = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false };
            Button create = ButtonOf("Utwórz folder sesji", CreateSession);
            Button open = ButtonOf("Otwórz folder", delegate { if (sessionPath == null) Tell("Najpierw utwórz folder sesji."); else OpenPath(sessionPath); });
            Button documentation = ButtonOf("Pełna instrukcja", delegate { ShowInstructions(); });
            sessionButtons.Controls.AddRange(new Control[] { create, open, documentation });
            sessions.Controls.Add(sessionButtons, 0, 2);
            page.Controls.Add(sessions, 0, 2);
            idleControls.Add(create);

            page.Controls.Add(LabelOf("2. Opcjonalnie: słuchaj oddzielnym odbiornikiem RS485", 11, orange), 0, 3);
            FlowLayoutPanel settings = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false };
            settings.Controls.Add(LabelOf("Port:", 10, Color.WhiteSmoke, 40));
            ConfigureCombo(port, 110);
            settings.Controls.Add(port);
            Button refresh = ButtonOf("Odśwież", delegate { RefreshPorts(); });
            refresh.Width = 98;
            settings.Controls.Add(refresh);
            settings.Controls.Add(LabelOf("Bod:", 10, Color.WhiteSmoke, 40));
            ConfigureCombo(baud, 94);
            foreach (int value in new int[] { 4800, 9600, 14400, 19200, 38400, 57600, 115200 }) baud.Items.Add(value.ToString());
            baud.SelectedItem = "9600";
            settings.Controls.Add(baud);
            ConfigureCombo(frame, 82);
            frame.Items.AddRange(new object[] { "8N1", "8N2", "8E1", "8E2", "8O1", "8O2" });
            frame.SelectedItem = "8N2";
            settings.Controls.Add(frame);
            settings.Controls.Add(LabelOf("Sekundy:", 10, Color.WhiteSmoke, 75));
            seconds.Minimum = 10;
            seconds.Maximum = 3600;
            seconds.Value = 120;
            seconds.Width = 82;
            StyleInput(seconds);
            settings.Controls.Add(seconds);
            page.Controls.Add(settings, 0, 4);
            idleControls.AddRange(new Control[] { port, refresh, baud, frame, seconds });

            isolated.Text = "Potwierdzam: to oddzielny, izolowany odbiornik z FIZYCZNIE zablokowanym TX.\nNie używam portu aktywnego Carela / narzędzia serwisowego.\nFormat transmisji dobieram do rzeczywistej magistrali.";
            isolated.Dock = DockStyle.Fill;
            isolated.AutoSize = false;
            isolated.Padding = new Padding(3);
            page.Controls.Add(isolated, 0, 5);
            idleControls.Add(isolated);

            FlowLayoutPanel recordingButtons = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false };
            ApplyButton(start, "Rozpocznij zapis bajtów", BeginCapture);
            start.Width = 240;
            ApplyButton(cancel, "Zakończ zapis (bez STOP silnika)", delegate { CancelCapture(); });
            cancel.Width = 330;
            cancel.Enabled = false;
            recordingButtons.Controls.AddRange(new Control[] { start, cancel });
            page.Controls.Add(recordingButtons, 0, 6);
            idleControls.Add(start);

            TableLayoutPanel results = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2 };
            results.RowStyles.Add(new RowStyle(SizeType.Absolute, 29));
            results.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            status.Text = "Gotowy. Żaden port nie jest otwarty.";
            status.Dock = DockStyle.Fill;
            status.ForeColor = orange;
            outcome.Text = "Brak zapisu i brak wyniku próby fizycznej.";
            outcome.Dock = DockStyle.Fill;
            results.Controls.Add(status, 0, 0);
            results.Controls.Add(outcome, 0, 1);
            page.Controls.Add(results, 0, 7);

            TextBox instructions = new TextBox {
                Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical, Dock = DockStyle.Fill,
                BorderStyle = BorderStyle.FixedSingle,
                Text = "CO DALEJ\r\n"
                    + "• Próbę przy osłoniętym wentylatorze prowadzi serwisant zatwierdzonym narzędziem lub działającym Carelem. Wcześniej sprawdza niezależne zatrzymanie sprzętowe.\r\n"
                    + "• Ten program tylko odbiera bajty. Nie wysyła poleceń MODBUS, także STOP. Zakończenie zapisu nie zatrzymuje silnika.\r\n"
                    + "• Brak bajtów nie oznacza uszkodzenia ani postoju silnika. Ten zapis nie rozróżnia wiarygodnie TX i RX; sam nie jest kwalifikowanym śladem próby.\r\n"
                    + "• Do przeglądu potrzeba rzeczywistego eksportu TX/RX z analizatora, niezależnych pomiarów obrotów oraz dowodów STOP i bezpiecznego powrotu. Wypełnij szablony rzeczywistymi wynikami.\r\n"
                    + "• Sprawdzenie kompletności i dopuszczenie wymagają osobnego przeglądu inżynierskiego. START pozostaje zablokowany."
            };
            instructions.BackColor = Color.FromArgb(32, 32, 32);
            instructions.ForeColor = Color.Gainsboro;
            page.Controls.Add(instructions, 0, 8);

            worker.DoWork += CaptureWork;
            worker.RunWorkerCompleted += CaptureFinished;
            FormClosing += BeforeClosing;
            RefreshPorts();
        }

        private Label LabelOf(string text, float size, Color color, int width = 0)
        {
            Label label = new Label { Text = text, Font = new Font("Segoe UI", size), ForeColor = color, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft };
            if (width > 0) { label.Dock = DockStyle.None; label.Size = new Size(width, 34); }
            return label;
        }
        private void StyleInput(Control input) { input.BackColor = Color.FromArgb(42, 42, 42); input.ForeColor = Color.WhiteSmoke; }
        private void ConfigureCombo(ComboBox combo, int width) { combo.Width = width; combo.DropDownStyle = ComboBoxStyle.DropDownList; StyleInput(combo); }
        private Button ButtonOf(string text, EventHandler handler) { Button button = new Button(); ApplyButton(button, text, handler); return button; }
        private void ApplyButton(Button button, string text, EventHandler handler)
        {
            button.Text = text;
            button.AutoSize = true;
            button.Height = 39;
            button.MinimumSize = new Size(110, 39);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderColor = orange;
            button.BackColor = Color.FromArgb(42, 42, 42);
            button.ForeColor = Color.WhiteSmoke;
            button.Padding = new Padding(8, 0, 8, 0);
            button.Click += handler;
        }
        private void Tell(string text) { MessageBox.Show(this, text, Text, MessageBoxButtons.OK, MessageBoxIcon.Information); }
        private void Report(string text) { MessageBox.Show(this, text, Text, MessageBoxButtons.OK, MessageBoxIcon.Error); }
        private void ShowInstructions()
        {
            try
            {
                string text = SessionFiles.Instructions(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "docs", "EC116_PROBA_STANOWISKOWA.md"));
                using (Form dialog = new Form { Text = "Pełna instrukcja próby EC116", StartPosition = FormStartPosition.CenterParent, Size = new Size(850, 700), BackColor = BackColor, ForeColor = ForeColor })
                {
                    TextBox reader = new TextBox { Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical, Dock = DockStyle.Fill, Font = new Font("Segoe UI", 10F), Text = text.Replace("\r\n", "\n").Replace("\n", "\r\n") };
                    StyleInput(reader);
                    dialog.Controls.Add(reader);
                    dialog.ShowDialog(this);
                }
            }
            catch (Exception error) { Report(error.Message); }
        }
        private void OpenPath(string path)
        {
            try
            {
                if (!File.Exists(path) && !Directory.Exists(path)) throw new FileNotFoundException("Nie znaleziono: " + path + "\nRozpakuj cały ZIP do jednego folderu.");
                Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
            }
            catch (Exception error) { Report(error.Message); }
        }
        private void CreateSession(object sender, EventArgs args)
        {
            using (FolderBrowserDialog dialog = new FolderBrowserDialog { Description = "Wybierz miejsce. Program utworzy w nim NOWY folder sesji EC116.", ShowNewFolderButton = true })
            {
                if (dialog.ShowDialog(this) != DialogResult.OK) return;
                try
                {
                    sessionPath = SessionFiles.Create(dialog.SelectedPath, Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "docs", "ec116-bench"));
                    folder.Text = sessionPath;
                    outcome.Text = "Utworzono puste szablony. Nie są wynikami pomiarów ani zgodą na START.";
                }
                catch (Exception error) { Report(error.Message); }
            }
        }
        private void RefreshPorts()
        {
            string previous = port.SelectedItem as string;
            port.Items.Clear();
            try
            {
                string[] names = SerialPort.GetPortNames();
                Array.Sort(names, StringComparer.OrdinalIgnoreCase);
                port.Items.AddRange(names);
                if (previous != null && port.Items.Contains(previous)) port.SelectedItem = previous;
                else if (port.Items.Count > 0) port.SelectedIndex = 0;
            }
            catch (Exception error) { status.Text = "Nie udało się wyświetlić portów: " + error.Message; }
        }
        private void SetBusy(bool busy)
        {
            foreach (Control control in idleControls) control.Enabled = !busy;
            cancel.Enabled = busy;
        }
        private void BeginCapture(object sender, EventArgs args)
        {
            if (sessionPath == null) { Tell("Najpierw utwórz folder sesji."); return; }
            if (port.SelectedItem == null) { Tell("Nie wykryto wybranego portu. Podłącz oddzielny odbiornik USB-RS485 i użyj Odśwież."); return; }
            if (!isolated.Checked) { Tell("Najpierw potwierdź oddzielny, izolowany odbiornik z fizycznie zablokowanym TX."); return; }
            if (MessageBox.Show(this, "Rozpocząć odbiór z " + port.SelectedItem + "?\n\nOdbiornik musi być oddzielny, izolowany i mieć fizycznie zablokowany TX. Nie można współdzielić portu aktywnego Carela.\n\nProgram nie wysyła STOP. Zakończenie zapisu nie zatrzyma silnika.", Text,
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) != DialogResult.Yes) return;
            recordingPath = Path.Combine(sessionPath, "raw_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + "_" + Guid.NewGuid().ToString("N").Substring(0, 8) + ".jsonl");
            RecordingSettings settings = new RecordingSettings { PortName = (string)port.SelectedItem, Baud = Int32.Parse((string)baud.SelectedItem), Frame = (string)frame.SelectedItem, Seconds = (int)seconds.Value, OutputPath = recordingPath };
            cancellation = new CancellationTokenSource();
            SetBusy(true);
            status.Text = "Otwieram oddzielny odbiornik…";
            outcome.Text = "Trwa tylko zapis odebranych bajtów. To nie jest pomiar RPM ani ocena silnika.";
            worker.RunWorkerAsync(settings);
        }
        private void CaptureWork(object sender, DoWorkEventArgs args)
        {
            RecordingSettings settings = (RecordingSettings)args.Argument;
            IReceiveOnlyPort receiver = new SerialReceiver(settings.PortName, settings.Baud, settings.Frame);
            try
            {
                args.Result = PassiveRecorder.Record(settings, receiver, cancellation.Token, delegate(long elapsed, long bytes) {
                    if (IsDisposed || !IsHandleCreated) return;
                    try { BeginInvoke((MethodInvoker)delegate { status.Text = "Zapis: " + (elapsed / 1000) + " / " + settings.Seconds + " s · odebrane bajty: " + bytes; }); }
                    catch (InvalidOperationException) { }
                });
            }
            catch
            {
                // Handles failures before the recorder could take ownership (for example CreateNew).
                try { receiver.Dispose(); } catch { }
                throw;
            }
        }
        private void CaptureFinished(object sender, RunWorkerCompletedEventArgs args)
        {
            SetBusy(false);
            cancellation.Dispose();
            cancellation = null;
            if (args.Error != null)
            {
                status.Text = "Zapis nie został poprawnie zakończony.";
                outcome.Text = "Błąd pliku / portu: " + args.Error.Message + "\nPlik może być niepełny: " + recordingPath;
            }
            else
            {
                RecordingResult result = (RecordingResult)args.Result;
                status.Text = result.Status == "completed" ? "Upłynął czas zapisu. Odbiornik zamknięty." : result.Status == "cancelled" ? "Przerwano zapis. Odbiornik zamknięty." : "Błąd zapisu lub zamknięcia odbiornika.";
                outcome.Text = "Bajty: " + result.ByteCount + ". " + (result.ByteCount == 0 ? "Brak bajtów nie oznacza usterki ani postoju silnika. " : "Kierunek TX/RX nie jest ustalony. ")
                    + (result.Error.Length > 0 ? "Błąd: " + result.Error + " " : "") + "\nPlik: " + result.OutputPath;
                if (result.Status == "error" && !closingAfterCapture)
                    Report("Nie udało się wykonać pełnego zapisu.\n" + result.Error + "\n\nSprawdź sterownik i oddzielny port odbiornika. Portu aktywnego Carela nie można współdzielić. Nie odłączaj go na potrzeby tego rejestratora.\n\nPlik zawiera oznaczenie błędu, o ile zapis na dysk był możliwy.");
            }
            if (closingAfterCapture) Close();
        }
        private void CancelCapture()
        {
            if (cancellation == null) return;
            cancellation.Cancel();
            cancel.Enabled = false;
            status.Text = "Kończę zapis i zamykam odbiornik. Nie wysyłam STOP silnika.";
        }
        private void BeforeClosing(object sender, FormClosingEventArgs args)
        {
            if (!worker.IsBusy) return;
            args.Cancel = true;
            closingAfterCapture = true;
            CancelCapture();
        }
    }

    public static class SelfTests
    {
        private sealed class FakeClock : IRecordingClock
        {
            public long Now;
            public void Restart() { Now = 0; }
            public long Milliseconds { get { return Now; } }
        }
        private sealed class FakeReceiver : IReceiveOnlyPort
        {
            public readonly FakeClock Clock;
            public bool FailOpen;
            public bool FailRead;
            public bool SendBytes;
            public int OpenCalls;
            public int ReadCalls;
            public bool Closed;
            public bool Disposed;
            public CancellationTokenSource CancelOnRead;
            public FakeReceiver(FakeClock clock) { Clock = clock; }
            public void Open() { OpenCalls++; if (FailOpen) throw new IOException("fake open failure"); }
            public int Read(byte[] buffer, int offset, int count)
            {
                ReadCalls++;
                Clock.Now += 500;
                if (CancelOnRead != null) CancelOnRead.Cancel();
                if (FailRead) throw new IOException("fake read failure\nwith detail");
                if (SendBytes && ReadCalls == 1) { buffer[offset] = 0xe7; buffer[offset + 1] = 0x04; return 2; }
                return 0;
            }
            public void Close() { Closed = true; }
            public void Dispose() { Disposed = true; }
        }
        private static void Check(bool condition, string message) { if (!condition) throw new Exception("SELF-TEST: " + message); }
        private static RecordingSettings Settings(string root, string name) { return new RecordingSettings { PortName = "FAKE", Baud = 9600, Frame = "8N2", Seconds = 10, OutputPath = Path.Combine(root, name) }; }
        public static int Run(string report)
        {
            string root = Path.Combine(Path.GetTempPath(), "climagold-ec116-tests-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(root);
            int passed = 0;
            try
            {
                Check(Json.Quote("a\n\"\\\t") == "\"a\\n\\\"\\\\\\t\"", "JSON escaping"); passed++;
                FakeClock clock = new FakeClock();
                FakeReceiver receiver = new FakeReceiver(clock) { SendBytes = true };
                RecordingResult completed = PassiveRecorder.Record(Settings(root, "complete.jsonl"), receiver, CancellationToken.None, null, clock);
                string text = File.ReadAllText(completed.OutputPath);
                Check(completed.Status == "completed" && completed.ByteCount == 2 && receiver.Closed && receiver.Disposed, "normal completion and port cleanup"); passed++;
                Check(text.Contains("\"direction\":\"observed\"") && !text.Contains("\"direction\":\"tx\"") && !text.Contains("\"direction\":\"rx\"") && text.Contains("\"start_authorized\":false") && text.Contains("\"direction_verified\":false"), "raw bytes never qualified or assigned TX/RX"); passed++;
                Check(text.StartsWith("{\"t_ms\":0,\"event\":\"capture_start\"") && text.Contains("\"event\":\"heartbeat\"") && text.EndsWith("}\n"), "capture framing, heartbeat, no BOM"); passed++;
                clock = new FakeClock(); receiver = new FakeReceiver(clock);
                bool refused = false;
                try { PassiveRecorder.Record(Settings(root, "complete.jsonl"), receiver, CancellationToken.None, null, clock); }
                catch (IOException) { refused = true; }
                Check(refused && receiver.OpenCalls == 0 && File.ReadAllText(completed.OutputPath) == text, "existing evidence protected before COM open"); passed++;
                clock = new FakeClock(); receiver = new FakeReceiver(clock);
                RecordingResult empty = PassiveRecorder.Record(Settings(root, "empty.jsonl"), receiver, CancellationToken.None, null, clock);
                Check(empty.Status == "completed" && empty.ByteCount == 0 && !File.ReadAllText(empty.OutputPath).Contains("rpm"), "empty capture has no fictional RPM or motor result"); passed++;
                using (CancellationTokenSource source = new CancellationTokenSource())
                {
                    clock = new FakeClock(); receiver = new FakeReceiver(clock) { CancelOnRead = source };
                    RecordingResult cancelled = PassiveRecorder.Record(Settings(root, "cancel.jsonl"), receiver, source.Token, null, clock);
                    Check(cancelled.Status == "cancelled" && receiver.Closed && File.ReadAllText(cancelled.OutputPath).Contains("\"completed\":false"), "cancellation honestly incomplete and port closed"); passed++;
                }
                clock = new FakeClock(); receiver = new FakeReceiver(clock) { FailRead = true };
                RecordingResult failed = PassiveRecorder.Record(Settings(root, "error.jsonl"), receiver, CancellationToken.None, null, clock);
                text = File.ReadAllText(failed.OutputPath);
                Check(failed.Status == "error" && text.Contains("fake read failure\\nwith detail") && text.Contains("\"interrupted\":true") && text.Contains("\"completed\":false") && receiver.Closed, "read failure recorded honestly"); passed++;
                clock = new FakeClock(); receiver = new FakeReceiver(clock) { FailOpen = true };
                failed = PassiveRecorder.Record(Settings(root, "open-error.jsonl"), receiver, CancellationToken.None, null, clock);
                Check(failed.Status == "error" && File.ReadAllText(failed.OutputPath).Contains("\"connection_opened\":false") && receiver.Disposed, "failed open cannot look like a live capture"); passed++;
                using (CancellationTokenSource source = new CancellationTokenSource())
                {
                    source.Cancel(); clock = new FakeClock(); receiver = new FakeReceiver(clock);
                    RecordingResult cancelled = PassiveRecorder.Record(Settings(root, "pre-cancel.jsonl"), receiver, source.Token, null, clock);
                    Check(cancelled.Status == "cancelled" && receiver.OpenCalls == 0, "cancel before start never opens receiver"); passed++;
                }
                string templates = Path.Combine(root, "templates"); Directory.CreateDirectory(templates);
                File.WriteAllText(Path.Combine(templates, "manifest.example.json"), "template manifest");
                File.WriteAllText(Path.Combine(templates, "commissioning-checklist.csv"), "template checklist");
                string session = SessionFiles.Create(root, templates);
                Check(File.ReadAllText(Path.Combine(session, "manifest.json")) == "template manifest" && File.ReadAllText(Path.Combine(session, "commissioning-checklist.csv")) == "template checklist", "session uses copied templates"); passed++;
                bool protectedTemplate = false;
                try { SessionFiles.CopyNew(Path.Combine(templates, "manifest.example.json"), Path.Combine(session, "manifest.json")); }
                catch (IOException) { protectedTemplate = true; }
                Check(protectedTemplate && File.ReadAllText(Path.Combine(session, "manifest.json")) == "template manifest", "template copying refuses overwrite"); passed++;
                string standalone = SessionFiles.Create(root, Path.Combine(root, "no-external-templates"));
                using (Stream embedded = Assembly.GetExecutingAssembly().GetManifestResourceStream("ClimaGold.manifest.json"))
                using (StreamReader expected = new StreamReader(embedded, Encoding.UTF8))
                    Check(File.ReadAllText(Path.Combine(standalone, "manifest.json")) == expected.ReadToEnd(), "standalone executable copies its exact embedded manifest");
                using (Stream embedded = Assembly.GetExecutingAssembly().GetManifestResourceStream("ClimaGold.checklist.csv"))
                using (StreamReader expected = new StreamReader(embedded, Encoding.UTF8))
                    Check(File.ReadAllText(Path.Combine(standalone, "commissioning-checklist.csv")) == expected.ReadToEnd(), "standalone executable copies its exact embedded checklist");
                passed++;
                string instructions = SessionFiles.Instructions(Path.Combine(root, "no-external-instructions.md"));
                Check(instructions.Length > 1000 && instructions.Contains("START") && instructions.Contains("EC116"), "standalone executable has full embedded instructions"); passed++;
                string result = "{\"self_tests_passed\":" + passed + ",\"serial_hardware_used\":false,\"physical_trial_verified\":false,\"start_authorized\":false}";
                if (report != null) File.WriteAllText(report, result + "\n", new UTF8Encoding(false));
                Console.WriteLine(result);
                return 0;
            }
            finally { Directory.Delete(root, true); }
        }
    }

    internal static class Program
    {
        private static string Argument(string[] args, string name)
        {
            int index = Array.IndexOf(args, name);
            return index >= 0 && index + 1 < args.Length ? args[index + 1] : null;
        }
        [STAThread]
        private static int Main(string[] args)
        {
            try
            {
                if (Array.IndexOf(args, "--self-test") >= 0) return SelfTests.Run(Argument(args, "--self-test-report"));
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                using (BenchForm form = new BenchForm())
                {
                    if (Array.IndexOf(args, "--smoke-test") >= 0)
                    {
                        form.Show();
                        Application.DoEvents();
                        string image = Argument(args, "--smoke-image");
                        if (image != null)
                            using (Bitmap bitmap = new Bitmap(form.Width, form.Height)) { form.DrawToBitmap(bitmap, form.ClientRectangle); bitmap.Save(image); }
                        string report = Argument(args, "--smoke-report");
                        if (report != null) File.WriteAllText(report, "{\"gui_started\":true,\"port_opened\":false,\"start_authorized\":false}\n", new UTF8Encoding(false));
                        form.Close();
                    }
                    else Application.Run(form);
                }
                return 0;
            }
            catch (Exception error)
            {
                if (Array.IndexOf(args, "--self-test") >= 0 || Array.IndexOf(args, "--smoke-test") >= 0) Console.Error.WriteLine(error);
                else MessageBox.Show("Nie udało się uruchomić programu.\n" + error.Message, "Clima Gold — próba EC116", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 1;
            }
        }
    }
}
