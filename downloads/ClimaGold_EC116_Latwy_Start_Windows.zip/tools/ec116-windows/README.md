# EC116 Windows helper source

Separate receive-only WinForms helper for Windows 10/11 and .NET Framework 4.x.
It uses no Python, external packages, network requests, motor commands or
application qualification changes. Serial control lines are disabled before
opening; a separate isolated receiver with physically disabled TX is required.

Build from the repository root with a .NET Framework-compatible C# compiler:

```text
mcs -target:winexe -platform:anycpu -r:System.Windows.Forms -r:System.Drawing -win32icon:windows/assets/climagold_dark.ico -resource:docs/ec116-bench/manifest.example.json,ClimaGold.manifest.json -resource:docs/ec116-bench/commissioning-checklist.csv,ClimaGold.checklist.csv -resource:docs/EC116_PROBA_STANOWISKOWA.md,ClimaGold.instructions.md -out:URUCHOM_EC116.exe tools/ec116-windows/Ec116Helper.cs
```

The embedded files make the executable standalone. Files from `docs/` beside
the executable take precedence when present. Session filenames use `CreateNew`
and existing recordings cannot be overwritten.

```text
URUCHOM_EC116.exe --self-test --self-test-report self-tests.json
URUCHOM_EC116.exe --smoke-test --smoke-report smoke.json --smoke-image preview.png
```

Self-tests use an injected receive-only port and fake clock; no real COM port is
opened. They cover file protection, received-byte provenance, empty recordings,
cancellation, read/open failures, cleanup, and standalone embedded templates.
The GUI smoke test also opens no COM port. Linux/Mono checks do not establish
native Windows compatibility or physical motor behavior.

Natural completion means only that the configured recording time elapsed.
Cancelled/error captures contain `completed:false` and `interrupted:true` when
the disk remains writable. No capture establishes RPM, STOP, TX/RX direction,
evidence qualification, or permission to START. Disk failures may leave a
truncated file and are reported separately by the GUI.
