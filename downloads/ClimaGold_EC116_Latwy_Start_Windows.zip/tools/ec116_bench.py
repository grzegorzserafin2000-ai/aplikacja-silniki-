#!/usr/bin/env python3
"""Non-actuating EC116 bench evidence tools.

`record` is a passive serial byte recorder: it never calls serial.write and
cannot distinguish a request from its echo. Its raw_chunk output is NOT a
qualified TX/RX trace. Use a physically receive-only isolated connection.

`validate` audits an explicitly exported TX/RX JSONL trace and independent
tachometer CSV (t_ms,rpm), using manifest.example.json. A complete packet is
only ready for engineering review: it never authorizes application START.
No command in this program transmits a MODBUS request, including STOP.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
import struct
import time

MODEL = "GR20V-4IP.Z8.AR"
PART = "192648"
PRODUCT, FIRMWARE, WATCHDOG = 0x0101, 2100, 0x0503
MAX_BYTES = 10 * 1024 * 1024
SNAPSHOT = {1: 0, 2: 0, 4: 3, 5: 1570, 7: 0, 17: 0, 30: 0}
FROZEN = (1, 2, 3, 4, 5, 7, 8, 16, 17, 25, 30)
IMMUTABLE = (1, 3, 4, 7, 8, 16, 25, 30)
BAUDS = (4800, 9600, 19200, 38400, 115200)
FRAMES = ("8N1", "8O1", "8E1", "8N2")


class EvidenceError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise EvidenceError(message)


def number(value, name):
    require(isinstance(value, (int, float)) and not isinstance(value, bool)
            and math.isfinite(value) and value >= 0, f"Invalid {name}")
    return value


def crc16(data):
    result = 0xffff
    for byte in data:
        result ^= byte
        for _ in range(8):
            result = (result >> 1) ^ (0xa001 if result & 1 else 0)
    return result


def artifact(root, name):
    require(isinstance(name, str) and name and not Path(name).is_absolute(), "Invalid artifact path")
    target = (root / name).resolve()
    require(target.is_relative_to(root.resolve()), "Artifact path escapes manifest directory")
    require(target.is_file() and 0 < target.stat().st_size <= MAX_BYTES, f"Missing/oversized artifact: {name}")
    return target


def load_trace(path, slave, timeout):
    events, transactions, pending = [], [], None
    previous = -1
    for line in path.read_text(encoding="utf-8").splitlines():
        require(len(line) <= 4096, "Oversized trace line")
        event = json.loads(line)
        stamp = number(event.get("t_ms"), "trace timestamp")
        require(stamp >= previous, "Non-monotonic trace timestamps")
        previous = stamp
        events.append(event)
        require(len(events) <= 100_000, "Too many trace events")
        if "event" in event:
            require(event["event"] in ("capture_start", "capture_end", "heartbeat"), "Unqualified recorder event/raw chunk")
            require("direction" not in event and "hex" not in event, "Metadata event cannot conceal RTU traffic")
            continue
        require(event.get("direction") in ("tx", "rx"), "Trace requires externally established TX/RX direction")
        raw = event.get("hex")
        require(isinstance(raw, str) and len(raw) <= 768, "Invalid RTU hex")
        packet = bytes.fromhex(raw)
        require(5 <= len(packet) <= 256, "Invalid RTU packet length")
        require(crc16(packet[:-2]) == int.from_bytes(packet[-2:], "little"), "RTU CRC mismatch")
        require(packet[0] == slave, "Wrong slave address in candidate trace")
        fn = packet[1]
        if event["direction"] == "tx":
            require(pending is None, "Overlapping requests / missing reply")
            require(fn in (3, 4, 6, 16), "Unsupported candidate request")
            require(len(packet) >= 8, "Invalid candidate request length")
            reg, value = struct.unpack(">HH", packet[2:6])
            if fn in (3, 4):
                require(len(packet) == 8 and 1 <= value <= 125
                        and reg + value <= 65536, "Invalid read count/length/range")
                values = None
            elif fn == 6:
                require(len(packet) == 8, "Invalid FC06 request length")
                values = [value]
            else:
                require(1 <= value <= 123 and reg + value <= 65536
                        and len(packet) == 9 + value * 2 and packet[6] == value * 2,
                        "Invalid FC16 quantity/byte count/payload/range")
                values = list(struct.unpack(">" + "H" * value, packet[7:-2]))
            pending = (stamp, packet, fn, reg, value, values)
        else:
            require(pending is not None, "Reply without a request")
            sent, request, expected, reg, value, values = pending
            require(0 <= stamp - sent <= timeout, "Reply exceeds declared timeout")
            require(fn == expected, "MODBUS exception or mismatched reply function")
            if fn == 6:
                require(packet == request, "Write reply is not the exact echo")
            elif fn == 16:
                require(len(packet) == 8 and packet[:6] == request[:6],
                        "FC16 reply does not echo the address and quantity")
            else:
                require(len(packet) == 5 + value * 2 and packet[2] == value * 2, "Invalid read reply length/count")
                values = list(struct.unpack(">" + "H" * value, packet[3:-2]))
            transactions.append({"sent": sent, "at": stamp, "fn": fn, "reg": reg, "values": values})
            pending = None
    require(pending is None, "Final request lacks its reply")
    starts = [e["t_ms"] for e in events if e.get("event") == "capture_start"]
    ends = [e["t_ms"] for e in events if e.get("event") == "capture_end"]
    require(len(starts) == len(ends) == 1 and starts[0] == events[0]["t_ms"]
            and ends[0] == events[-1]["t_ms"] and starts[0] < ends[0], "Missing complete capture boundaries")
    return events, transactions


def load_tachometer(path):
    samples = []
    with path.open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream)
        require(reader.fieldnames == ["t_ms", "rpm"], "Independent tachometer CSV requires t_ms,rpm")
        for row in reader:
            stamp, rpm = number(float(row["t_ms"]), "tachometer timestamp"), number(float(row["rpm"]), "tachometer RPM")
            require(not samples or stamp > samples[-1][0], "Non-monotonic tachometer timestamps")
            samples.append((stamp, rpm))
            require(len(samples) <= 100_000, "Too many tachometer samples")
    require(samples, "Missing independent tachometer observations")
    return samples


def zero_span(samples):
    return len(samples) >= 3 and samples[-1] - samples[0] >= 600


def validate_manifest(path):
    """Return completeness for human review, never a motor movement permit."""
    result = {"review_ready": False, "start_authorized": False, "manual_review_required": True,
              "errors": [], "scope": "evidence completeness only; no physical verification performed"}
    try:
        path = Path(path)
        require(path.is_file() and path.stat().st_size <= 65536, "Missing/oversized manifest")
        manifest = json.loads(path.read_text(encoding="utf-8"))
        require(manifest.get("schema_version") == 1, "Unsupported manifest schema")
        require(manifest.get("provenance") == "physical", "Simulation is not physical qualification evidence")
        require(isinstance(manifest.get("operator"), str) and manifest["operator"].strip(), "Missing named operator")
        unit = manifest["unit"]
        require(unit.get("model") == MODEL and str(unit.get("part_number")) == PART
                and unit.get("product") == PRODUCT and unit.get("firmware") == FIRMWARE,
                "Wrong model / part number / product / firmware")
        slave = unit["slave"]
        require(isinstance(slave, int) and not isinstance(slave, bool) and 1 <= slave <= 247, "Invalid slave")
        baud, frame = unit["baud"], unit["frame"]
        require(isinstance(baud, int) and not isinstance(baud, bool) and baud in BAUDS
                and frame in FRAMES, "Unsupported unit baud/framing for h3")
        communication_word = (slave << 8) | (BAUDS.index(baud) << 4) | FRAMES.index(frame)
        signature = unit["device_signature"]
        require(isinstance(signature, list) and len(signature) == 6
                and all(isinstance(word, int) and not isinstance(word, bool)
                        and 0 <= word <= 65535 for word in signature)
                and any(signature),
                "Device signature requires six unsigned 16-bit words from i3..i8, not all zero")
        parameter_set = {2: unit.get("parameter_set_id"), 9: unit.get("parameter_set_index")}
        require(all(isinstance(word, int) and not isinstance(word, bool) and 0 <= word <= 65535
                    for word in parameter_set.values()),
                "Parameter set ID/index require actual unsigned 16-bit words from i2/i9")
        require(manifest.get("capture_scope") == "whole_bus", "Capture must cover the whole RTU bus")
        require(manifest.get("manual_emergency_stop_used") is False, "Manual emergency stop cannot prove automatic communication-loss STOP")
        root = path.parent
        stop = manifest["external_stop"]
        require(isinstance(stop.get("description"), str) and stop["description"].strip(), "Missing independent hardware-stop description")
        artifact(root, stop["tested_artifact"])
        artifact(root, manifest["trial_artifact"])
        recovery = manifest["recovery"]
        strategy = recovery.get("strategy")
        require(strategy in ("independent_inhibit", "safe_power_cycle"), "Unsupported recovery strategy")
        artifact(root, recovery["evidence_artifact"])
        if strategy == "independent_inhibit":
            inhibit_start = number(recovery["inhibit_start_ms"], "inhibit start")
            inhibit_end = number(recovery["inhibit_end_ms"], "inhibit end")
            require(inhibit_start < inhibit_end, "Invalid independent-inhibit window")
        else:
            power_off = number(recovery["power_off_ms"], "power off")
            power_on = number(recovery["power_on_ms"], "power on")
            ready = number(recovery["ready_ms"], "power-cycle ready")
        loss = manifest["loss"]
        loss_start, loss_end = number(loss["start_ms"], "silence start"), number(loss["end_ms"], "silence end")
        deadline = number(loss["stop_deadline_ms"], "loss STOP deadline")
        require(0 < deadline <= 260000 and loss_end - loss_start >= deadline, "Invalid loss observation/deadline window")
        if strategy == "independent_inhibit":
            require(inhibit_start >= loss_end and inhibit_end > loss_end,
                    "Recovery inhibition must begin at/after silence ends and cover return of communication")
        else:
            require(loss_end <= power_off < power_on <= ready, "Invalid safe-power-cycle off/on/ready ordering")
        timeout = number(manifest.get("reply_timeout_ms", 1000), "reply timeout")
        require(0 < timeout <= 3000, "Invalid reply timeout")
        events, transactions = load_trace(artifact(root, manifest["trace"]), slave, timeout)
        tachometer = load_tachometer(artifact(root, manifest["tachometer"]))
        require(events[0]["t_ms"] <= tachometer[0][0] and events[-1]["t_ms"] >= tachometer[-1][0], "Capture does not cover independent measurements")
        if strategy == "safe_power_cycle":
            require(not any("direction" in event for event in events
                            if power_off <= event["t_ms"] <= ready),
                    "RTU traffic occurred during the safe-power-cycle off/ready interval")
            first_recovery = next((tx for tx in transactions if tx["sent"] > loss_end), None)
            require(first_recovery is not None and first_recovery["sent"] > ready,
                    "Power-cycle recovery traffic must begin after ready_ms")
            require(first_recovery["fn"] == 3 and first_recovery["reg"] <= 2
                    < first_recovery["reg"] + len(first_recovery["values"])
                    and first_recovery["values"][2 - first_recovery["reg"]] == 0,
                    "First power-cycle recovery transaction must read actual h2=0 before any write")
            boot_zeros = [stamp for stamp, rpm in tachometer
                          if power_on < stamp < first_recovery["sent"] and rpm == 0]
            require(zero_span(boot_zeros),
                    "Power-cycle recovery needs three independent post-on zero samples spanning 600ms before RTU traffic")
        quiet = [e for e in events if loss_start <= e["t_ms"] <= loss_end]
        require(not any("direction" in e for e in quiet), "RTU traffic occurred during the declared silence")
        heartbeats = [loss_start] + [e["t_ms"] for e in quiet if e.get("event") == "heartbeat"] + [loss_end]
        require(all(b - a <= 1000 for a, b in zip(heartbeats, heartbeats[1:])), "Recorder continuity during bus silence is not evidenced")
        require(any(loss_start - 500 <= t <= loss_start + 500 and rpm > 0 for t, rpm in tachometer), "Loss trial lacks fresh independent positive RPM")
        zero_tacho = []
        first_zero_established = None
        for stamp, rpm in tachometer:
            if loss_start <= stamp <= loss_start + deadline:
                if rpm == 0:
                    zero_tacho.append(stamp)
                    if first_zero_established is None and zero_span(zero_tacho):
                        first_zero_established = stamp
                else:
                    zero_tacho.clear()
        require(zero_span(zero_tacho), "Independent loss STOP needs three zero-RPM samples spanning 600ms before the deadline")
        established_at = next(stamp for index, stamp in enumerate(zero_tacho)
                              if index >= 2 and stamp - zero_tacho[0] >= 600)
        if strategy == "independent_inhibit":
            require(established_at < inhibit_start, "Independent zero RPM must be established before recovery inhibition")
        else:
            established_at = first_zero_established
            require(established_at < power_off, "Independent automatic loss STOP must be established strictly before power off")
        require(not any(rpm > 0 for t, rpm in tachometer if zero_tacho[-1] <= t <= loss_end), "Independent RPM resumed during silence")

        observed, writes, episodes = {}, {}, []
        first_write = None
        original = {}
        zero_readback = -1
        restore_at = -1
        loss_demand_confirmed = False

        def held(reg, value):
            sample = observed.get((3, reg))
            return sample is not None and sample[0] == value and sample[1] >= writes.get(reg, -1)

        def stopped():
            return bool(episodes and episodes[-1].get("stop") is not None and zero_span(episodes[-1]["zeros"]))

        for tx in transactions:
            sent, at, fn, reg, values = tx["sent"], tx["at"], tx["fn"], tx["reg"], tx["values"]
            if strategy == "independent_inhibit" and sent > loss_end and zero_readback < loss_end:
                require(inhibit_start <= sent <= inhibit_end, "Recovery traffic before clearing old demand lacks independent inhibition")
            if sent > loss_start and not loss_demand_confirmed:
                require(held(2, episodes[-1]["demand"]) if episodes else False, "Loss trial did not begin with a positive read-back task")
                loss_demand_confirmed = True
            if fn in (3, 4):
                for offset, value in enumerate(values):
                    address = reg + offset
                    observed[(fn, address)] = (value, at)
                    if fn == 4 and address in (0, 1):
                        require(value == (FIRMWARE if address == 0 else PRODUCT), "Observed motor identity changed")
                    if fn == 4 and 3 <= address <= 8:
                        require(value == signature[address - 3], "Observed device signature changed/mismatches manifest")
                    if fn == 4 and address in parameter_set:
                        require(value == parameter_set[address], f"Observed parameter set i{address} changed/mismatches manifest")
                    if fn == 4 and address in (12, 13):
                        require(value == 0, f"Nonzero observed status i{address}")
                    if fn == 3 and address == 3:
                        require(value == communication_word, "Observed h3 does not match unit slave/baud/framing")
                    if fn == 3 and original and address in IMMUTABLE:
                        require(value == original[address], f"Frozen configuration h{address} changed during trial")
                    if fn == 3 and address == 2 and value == 0:
                        zero_readback = at
                    if fn == 4 and address == 14 and episodes:
                        episode = episodes[-1]
                        if value > 0 and episode["stop"] is None:
                            episode["positive"].append(at)
                        if episode["stop"] is not None and zero_readback >= episode["stop"]:
                            if value == 0:
                                episode["zeros"].append(at)
                            else:
                                episode["zeros"].clear()
                continue
            for address in range(reg, reg + len(values)):
                require(address in (0, 2, 5, 17), f"Unsupported candidate register write h{address}")
            if first_write is None:
                first_write = sent
                for address, expected in SNAPSHOT.items():
                    require(held(address, expected), f"Missing initial snapshot h{address}={expected}")
                require(held(3, communication_word), "Missing verified original communication word")
                require((4, 1) in observed and (4, 0) in observed and observed.get((4, 14), (-1,))[0] == 0, "Missing initial identity/zero RPM")
                require(all((4, address) in observed for address in (*range(3, 9), 12, 13)),
                        "Missing initial device signature / actual i12/i13 status reads")
                require(all((4, address) in observed for address in parameter_set),
                        "Missing initial actual parameter set i2/i9 reads")
                require((3, 8) in observed and 1 <= observed[(3, 8)][0] <= 6000, "Missing maximum-speed setting")
                require((3, 16) in observed and observed[(3, 16)][0] & 14 == 0, "Nonzero/unknown startup task")
                require((3, 25) in observed, "Missing ramp word")
                original = {r: observed[(3, r)][0] for r in FROZEN}
            for offset, value in enumerate(values):
                address = reg + offset
                if address == 0:
                    require(value == 10, "Reset/unsupported PIN is forbidden")
                elif address == 2:
                    require(value == 0 or value in range(10, 101, 10), "Unsupported percentage task")
                    if value > 0:
                        require(sent < loss_start, "Positive task after communication-loss trial is forbidden")
                        require(held(5, 0) and held(17, WATCHDOG) and held(4, 3), "Positive task lacks zero fallback and verified armed watchdog")
                        if episodes:
                            require(stopped(), "New task before the previous STOP was observed")
                        episodes.append({"start": sent, "demand": value, "positive": [], "stop": None, "zeros": []})
                    elif episodes and episodes[-1]["stop"] is None:
                        require(episodes[-1]["positive"], "STOP trial never observed positive MODBUS RPM")
                        episodes[-1]["stop"] = sent
                elif address == 17:
                    require(value in (0, WATCHDOG), "Unsupported watchdog mode")
                    if value == WATCHDOG:
                        require(held(5, 0), "Nonzero/unverified h5 when arming watchdog")
                    elif episodes:
                        require(held(2, 0) and stopped(), "Watchdog disarmed before confirmed STOP")
                elif address == 5:
                    require(value in (0, 1570), "Unexpected fallback value")
                    if value != 0:
                        require(held(17, 0) and held(2, 0) and stopped(), "Nonzero h5 restored before watchdog disarm/readback and STOP")
                        restore_at = at
                writes[address] = at

        require(len(episodes) >= 2 and loss_demand_confirmed, "Missing separate normal STOP and communication-loss trials")
        normal = [e for e in episodes if e["stop"] is not None and e["stop"] < loss_start and zero_span(e["zeros"])]
        require(normal, "No measured normal STOP with three zero-RPM samples spanning600ms")
        require(stopped() and restore_at > loss_end, "Missing confirmed recovery STOP / restoration")
        for reg, expected in original.items():
            require(held(reg, expected) and observed[(3, reg)][1] >= restore_at, f"Final snapshot/readback h{reg} differs or is stale")
        require(all(observed.get((4, reg), (-1, -1))[1] >= restore_at
                    for reg in (0, 1, *range(2, 10), 12, 13)),
                "Missing final identity / signature / parameter set / actual i12/i13 status after restoration")
        if strategy == "independent_inhibit":
            after_release = [t for t, rpm in tachometer if t >= inhibit_end and rpm == 0]
            require(zero_span(after_release) and after_release[-1] >= max(inhibit_end, restore_at) + 600,
                    "No independent no-restart observation after inhibition release")
            no_restart_since = zero_tacho[-1]
        else:
            after_restore = [t for t, rpm in tachometer if t >= restore_at and rpm == 0]
            require(zero_span(after_restore) and after_restore[-1] >= restore_at + 600,
                    "No independent no-restart observation after power-cycle restoration")
            no_restart_since = established_at
        require(not any(rpm > 0 for t, rpm in tachometer if t >= no_restart_since), "Independent RPM restarted after the loss STOP")
        result.update(review_ready=True, transactions=len(transactions), independent_rpm_samples=len(tachometer),
                      warning="Complete evidence still needs engineering review; never imports an application movement permit.")
    except (EvidenceError, KeyError, ValueError, TypeError, OSError, UnicodeError, IndexError) as exc:
        result["errors"].append(str(exc) or type(exc).__name__)
    return result


def record_serial(port, baud, frame, seconds, output, serial_factory=None, monotonic=time.monotonic):
    """Record only received bytes; raw output deliberately cannot pass validate."""
    require(isinstance(port, str) and port, "An explicit serial port is required")
    require(baud in (4800, 9600, 19200, 38400, 57600, 115200, 14400), "Invalid baud")
    require(frame in ("8N1", "8N2", "8E1", "8E2", "8O1", "8O2"), "Invalid framing")
    require(isinstance(seconds, (int, float)) and not isinstance(seconds, bool) and 0 < seconds <= 3600, "Recording duration must be1..3600s")
    if serial_factory is None:
        import serial
        serial_factory = serial.Serial
    serial_port = serial_factory(port=port, baudrate=baud, bytesize=8, parity=frame[1], stopbits=int(frame[2]), timeout=0.1)
    try:
        serial_port.rts = False
        serial_port.dtr = False
        with Path(output).open("x", encoding="utf-8") as stream:
            started = monotonic()
            def emit(event, **fields):
                stream.write(json.dumps({"t_ms": round((monotonic()-started)*1000, 3), "event": event, **fields})+"\n")
                stream.flush()
            emit("capture_start", read_only=True, port=port, baud=baud, frame=frame, scope="passive bytes; direction unverified")
            heartbeat = started
            while monotonic()-started < seconds:
                chunk = serial_port.read(min(4096, max(1, serial_port.in_waiting)))
                if chunk:
                    emit("raw_chunk", direction="observed", hex=chunk.hex(" "))
                if monotonic()-heartbeat >= 0.5:
                    emit("heartbeat")
                    heartbeat = monotonic()
            emit("capture_end", read_only=True)
    finally:
        serial_port.close()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    check = commands.add_parser("validate", help="Audit evidence completeness; never authorize START")
    check.add_argument("manifest", type=Path)
    record = commands.add_parser("record", help="Receive-only byte capture; requires physically disabled TX")
    record.add_argument("--port", required=True)
    record.add_argument("--baud", required=True, type=int)
    record.add_argument("--frame", required=True)
    record.add_argument("--seconds", required=True, type=float)
    record.add_argument("--output", required=True, type=Path)
    args = parser.parse_args(argv)
    if args.command == "validate":
        result = validate_manifest(args.manifest)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["review_ready"] else 2
    record_serial(args.port, args.baud, args.frame, args.seconds, args.output)
    print("Recorded receive-only bytes. No MODBUS commands were transmitted; output is not a qualified TX/RX trial.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
